import fs from 'fs';
import path from 'path';
import { Pool } from 'pg';
import bcrypt from 'bcryptjs';
import {
  Batch,
  CommitteeMember,
  Committee,
  CommitteeMemberItem,
  CommitteeDesignation,
  OfflineRegistrationCenter,
  EventItem,
  Notice,
  NewsPost,
  SchoolInfo,
  AssociationInfo,
  SiteSettings,
  GlobalSettings,
  HeaderConfig,
  TopBarConfig,
  NavigationMenuItem,
  FooterConfig,
  CMSPage,
  FAQItem,
  PaymentGatewayConfig,
  RegistrationConfig,
  TokenFormatConfig,
  BatchConfig,
  CustomRole,
  User,
  Registration,
  PaymentTransaction,
  PaymentStatus,
  EntryToken,
  AuditLog,
  MediaItem,
  ProgramScheduleSectionConfig,
  RegistrationFieldConfig,
  GateItem,
  HeroConfig,
  MailSettings,
} from '../src/types';
import { initialMailSettings } from './services/mailService';
import {
  initialBatches,
  initialEvent,
  initialSchoolInfo,
  initialAssociationInfo,
  initialCommittee,
  initialCommittees,
  initialCommitteeMembers,
  initialDesignations,
  initialOfflineCenters,
  initialNotices,
  initialNews,
  initialGlobalSettings,
  initialHeaderConfig,
  initialTopBarConfig,
  initialMenus,
  initialFooterConfig,
  initialPages,
  initialFAQs,
  initialPaymentGateways,
  initialRegistrationConfig,
  initialTokenFormatConfig,
  initialRegistrationFields,
  initialProgramSchedule,
  initialBatchConfig,
  initialRoles,
  initialUsers,
  initialRegistrations,
  initialTokens,
  initialGates,
  initialHeroConfig,
  initialRegistrationConfirmationConfig,
  initialSettingsTable,
} from './seedData';
import { portableDb } from './db/portableDb';
import { parsePostgresUrl } from './db/config';
import { RegistrationConfirmationConfig, SettingItem } from '../src/types';

export interface DatabaseSchema {
  settings_table?: SettingItem[];
  batches: Batch[];
  events: EventItem[];
  gates: GateItem[];
  school_info: SchoolInfo;
  association_info: AssociationInfo;
  committee: CommitteeMember[];
  committees: Committee[];
  committee_members: CommitteeMemberItem[];
  committee_designations: CommitteeDesignation[];
  offline_centers: OfflineRegistrationCenter[];
  notices: Notice[];
  news: NewsPost[];
  media: MediaItem[];
  settings: SiteSettings;
  global_settings: GlobalSettings;
  header_config: HeaderConfig;
  top_bar_config: TopBarConfig;
  menus: NavigationMenuItem[];
  footer_config: FooterConfig;
  pages: CMSPage[];
  faqs: FAQItem[];
  payment_gateways: PaymentGatewayConfig[];
  registration_config: RegistrationConfig;
  registration_confirmation_config: RegistrationConfirmationConfig;
  token_format_config: TokenFormatConfig;
  batch_config: BatchConfig;
  roles: CustomRole[];
  users: (User & { password_hash?: string })[];
  registrations: Registration[];
  payments: PaymentTransaction[];
  tokens: EntryToken[];
  audit_logs: AuditLog[];
  program_schedule: ProgramScheduleSectionConfig;
  registration_form_fields: RegistrationFieldConfig[];
  hero_config: HeroConfig;
  animations_config?: import('../src/types').AnimationConfig;
  mail_settings?: MailSettings;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

export const DUMMY_REG_NAMES = [
  'Mushtaq Ahmed', 'Sayem Sheikh', 'Mahbub Alam', 'Dr. Fazlul Karim', 
  'Professor Anisur Rahman', 'Engr. Zahidul Islam Chowdhury', 
  'Audit Verification Alumni', 'Test Alumnus Persistence', 'Test Mail',
  'Attendee Size M', 'Attendee Size XL', 'Automated Email Test Alumnus',
  'Valid Alumni', 'Valid Alumni Updated'
];

export const DUMMY_REG_IDS = [
  'REG-85-186949', 'REG-85-704859', 'REG-85-340696', 'REG-85-055068', 
  'REG-85-299344', 'REG-85-955829', 'REG-85-862178763', 'REG-85-838121377', 
  'REG-85-520992996', 'REG-85-852169', 'REG-85-512497', 'REG-85-896430', 
  'REG-85-511690', 'REG-85-818455', 'REG-85-430875', 'REG-85-615355', 
  'REG-85-815034', 'REG-85-476561', 'REG-85-900532', 'REG-85-755494'
];

export function isDummyRegistration(r: any): boolean {
  if (!r) return true;
  if (DUMMY_REG_IDS.includes(r.id)) return true;
  if (DUMMY_REG_NAMES.includes(r.full_name)) return true;
  if (typeof r.full_name === 'string') {
    const fn = r.full_name.toLowerCase();
    if (fn.includes('audit verification') || fn.includes('test alumnus') || fn.includes('test mail') || fn.includes('test attendee')) {
      return true;
    }
  }
  if (typeof r.email === 'string') {
    const em = r.email.toLowerCase();
    if (em.endsWith('@example.org') || em.includes('alumni_1791') || em === 'dsdsd@dsd.com' || em === 'testalumnus9988@nanupuralumni.local') {
      return true;
    }
  }
  return false;
}

class DatabaseEngine {
  private data: DatabaseSchema;
  private pool: Pool | null = null;
  private isSupabaseConnected: boolean = false;

  constructor() {
    this.data = this.loadInitialData();
    this.initSupabasePool();
    this.hydrateFromConfiguredDatabase();
  }

  public async hydrateFromConfiguredDatabase(): Promise<void> {
    try {
      const dbData = await portableDb.loadAllEntities();
      let hydratedAny = false;
      for (const [key, val] of Object.entries(dbData)) {
        if (val !== undefined && val !== null) {
          if (Array.isArray(val) && val.length > 0) {
            if (key === 'users') {
              (this.data as any)[key] = this.sanitizeAndDeduplicateUsers(val);
            } else if (key === 'registrations') {
              const remoteRegs = val as any[];
              const merged = [...remoteRegs];
              for (const lr of (this.data.registrations || [])) {
                if (isDummyRegistration(lr)) continue;
                if (!remoteRegs.some(rr => rr.id === lr.id || (lr.phone && rr.phone === lr.phone))) {
                  merged.push(lr);
                }
              }
              this.data.registrations = merged;
            } else if (key === 'tokens') {
              const remoteTokens = val as any[];
              const merged = [...remoteTokens];
              for (const lt of (this.data.tokens || [])) {
                if (!lt || !lt.id) continue;
                if (!remoteTokens.some(rt => rt.id === lt.id || (lt.token_code && rt.token_code === lt.token_code))) {
                  merged.push(lt);
                }
              }
              this.data.tokens = merged;
            } else if (key === 'payments') {
              const remotePayments = val as any[];
              const merged = [...remotePayments];
              for (const lp of (this.data.payments || [])) {
                if (!lp || !lp.id) continue;
                if (!remotePayments.some(rp => rp.id === lp.id || (lp.transaction_id && rp.transaction_id === lp.transaction_id))) {
                  merged.push(lp);
                }
              }
              this.data.payments = merged;
            } else {
              (this.data as any)[key] = val;
            }
            hydratedAny = true;
          } else if (!Array.isArray(val) && typeof val === 'object' && Object.keys(val).length > 0) {
            (this.data as any)[key] = val;
            hydratedAny = true;
          }
        }
      }
      if (hydratedAny) {
        this.saveData();
        console.log('[DatabaseEngine] Authoritative database records successfully hydrated into runtime memory.');
      }
    } catch (err: any) {
      console.warn('[DatabaseEngine] Database hydration note:', err.message);
    }
  }

  private parsePostgresConfig(rawUrl?: string) {
    if (!rawUrl) return null;
    try {
      const prefix = 'postgresql://';
      if (!rawUrl.startsWith(prefix)) return null;
      const rest = rawUrl.slice(prefix.length);
      const lastAt = rest.lastIndexOf('@');
      if (lastAt === -1) return null;
      const userPass = rest.slice(0, lastAt);
      const hostPart = rest.slice(lastAt + 1);
      const firstColon = userPass.indexOf(':');
      const user = userPass.slice(0, firstColon);
      const password = userPass.slice(firstColon + 1);
      const [hostPort, dbName] = hostPart.split('/');
      const [host, port] = hostPort.split(':');

      return {
        user,
        password,
        host,
        port: parseInt(port || '5432', 10),
        database: dbName || 'postgres',
        ssl: { rejectUnauthorized: false },
        connectionTimeoutMillis: 5000,
        max: 10,
      };
    } catch (e) {
      console.warn('Could not parse DATABASE_URL:', e);
      return null;
    }
  }

  private async initSupabasePool() {
    const rawUrl = process.env.DATABASE_URL;
    const config = parsePostgresUrl(rawUrl);
    if (!config) {
      console.log('No PostgreSQL/Supabase DATABASE_URL configured. Using local JSON store.');
      return;
    }

    try {
      this.pool = new Pool({
        user: config.user,
        password: config.password,
        host: config.host,
        port: config.port,
        database: config.database,
        ssl: config.ssl,
        connectionTimeoutMillis: 8000,
        max: 10,
      });
      const client = await this.pool.connect();
      await client.query('SELECT 1');
      console.log('Connected to Supabase PostgreSQL database successfully.');
      this.isSupabaseConnected = true;
      client.release();

      // Hydrate from Supabase or seed to Supabase
      await this.syncWithSupabase();
    } catch (err: any) {
      console.warn('Supabase initial connection note (operating on memory & file cache):', err.message);
    }
  }

  private async syncWithSupabase() {
    if (!this.pool || !this.isSupabaseConnected) return;
    try {
      // 1. Hydrate Site Settings
      try {
        const res = await this.pool.query('SELECT key, value FROM site_settings');
        if (res.rows && res.rows.length > 0) {
          console.log(`Loaded ${res.rows.length} configuration settings from Supabase.`);
          for (const row of res.rows) {
            if (row.key && row.value !== undefined) {
              try {
                (this.data as any)[row.key] = typeof row.value === 'string' ? JSON.parse(row.value) : row.value;
              } catch {
                (this.data as any)[row.key] = row.value;
              }
            }
          }
        }

        // Ensure all authoritative initial pages exist if not present in site_settings
        if (Array.isArray(this.data.pages)) {
          // Remove dummy test pages
          this.data.pages = this.data.pages.filter(p => !p.slug.startsWith('ctrl-test'));
          for (const initPage of initialPages) {
            const exists = this.data.pages.find(p => p.slug === initPage.slug || p.id === initPage.id);
            if (!exists) {
              this.data.pages.push(initPage);
            }
          }
          await this.persistKeyToSupabase('pages', this.data.pages);
        }

        // Ensure t_shirt_size field exists in registration_form_fields and registration_config
        if (Array.isArray(this.data.registration_form_fields)) {
          const hasTShirt = this.data.registration_form_fields.some((f: any) => f.name === 't_shirt_size');
          if (!hasTShirt) {
            const defaultTShirt = initialRegistrationFields.find(f => f.name === 't_shirt_size');
            if (defaultTShirt) {
              this.data.registration_form_fields.push(defaultTShirt);
              this.data.registration_form_fields.sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
              await this.persistKeyToSupabase('registration_form_fields', this.data.registration_form_fields);
            }
          }
        }
        if (this.data.registration_config && Array.isArray(this.data.registration_config.fields)) {
          const hasTShirt = this.data.registration_config.fields.some((f: any) => f.name === 't_shirt_size');
          if (!hasTShirt) {
            const defaultTShirt = initialRegistrationFields.find(f => f.name === 't_shirt_size');
            if (defaultTShirt) {
              this.data.registration_config.fields.push(defaultTShirt);
              this.data.registration_config.fields.sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
              await this.persistKeyToSupabase('registration_config', this.data.registration_config);
            }
          }
          if (!this.data.registration_config.max_image_size_mb) {
            this.data.registration_config.max_image_size_mb = 1.5;
          }
          if (!this.data.registration_config.image_accepted_formats) {
            this.data.registration_config.image_accepted_formats = ['image/jpeg', 'image/png', 'image/webp'];
          }
          if (!this.data.registration_confirmation_config) {
            this.data.registration_confirmation_config = initialRegistrationConfirmationConfig;
          }
        }
      } catch (sErr: any) {
        console.warn('Site settings sync note:', sErr.message);
      }

      // 2. Hydrate Batches
      try {
        const bRes = await this.pool.query('SELECT * FROM batches ORDER BY passing_year DESC');
        if (bRes.rows && bRes.rows.length > 0) {
          this.data.batches = bRes.rows.map(b => ({
            id: b.id,
            name_en: b.name_en,
            name_bn: b.name_bn,
            passing_year: b.passing_year,
            batch_number: b.batch_number,
            representative_name: b.representative_name,
            representative_phone: b.representative_phone,
            registration_count: Number(b.registration_count) || 0,
            is_active: b.is_active !== false,
          }));
        } else if (this.data.batches && this.data.batches.length > 0) {
          await this.persistKeyToSupabase('batches', this.data.batches);
        }
      } catch (bErr: any) {
        console.warn('Batches sync note:', bErr.message);
      }

      // 3. Hydrate Events
      try {
        const evRes = await this.pool.query('SELECT * FROM events');
        if (evRes.rows && evRes.rows.length > 0) {
          this.data.events = evRes.rows.map(e => ({
            id: e.id,
            slug: e.slug || '85th-anniversary',
            title_en: e.title_en,
            title_bn: e.title_bn,
            tagline_en: e.tagline_en || '',
            tagline_bn: e.tagline_bn || '',
            description_en: e.description_en || '',
            description_bn: e.description_bn || '',
            event_date: e.event_date ? new Date(e.event_date).toISOString().split('T')[0] : '2027-01-16',
            start_time: e.start_time || '09:00 AM',
            end_time: e.end_time || '06:00 PM',
            registration_start: e.registration_start || '2026-01-01',
            registration_end: e.registration_end || '2026-12-31',
            max_capacity: Number(e.max_capacity) || 5000,
            venue_en: e.venue_en || 'School Grounds',
            venue_bn: e.venue_bn || 'বিদ্যালয় প্রাঙ্গণ',
            registration_fee: Number(e.registration_fee) || 1000,
            currency: e.currency || 'BDT',
            status: e.status || 'upcoming',
          }));
        } else if (this.data.events && this.data.events.length > 0) {
          await this.persistKeyToSupabase('events', this.data.events);
        }
      } catch (evErr: any) {
        console.warn('Events sync note:', evErr.message);
      }

      // 4. Hydrate Users
      try {
        const uRes = await this.pool.query('SELECT * FROM users ORDER BY created_at ASC');
        if (uRes.rows && uRes.rows.length > 0) {
          console.log(`Loaded ${uRes.rows.length} users from Supabase.`);
          let remoteUsers: (User & { password_hash?: string })[] = uRes.rows.map(r => ({
            id: r.id,
            username: r.username || (r.email ? r.email.split('@')[0] : 'user'),
            name: r.name,
            name_bn: r.name_bn || undefined,
            email: r.email,
            phone: r.phone,
            password_hash: r.password_hash,
            role: r.role || 'alumni_member',
            status: r.status || (r.is_active ? 'active' : 'inactive'),
            passing_year: r.passing_year,
            batch: r.batch,
            dob: r.dob,
            gender: r.gender,
            blood_group: r.blood_group,
            photo_url: r.photo_url || r.avatar_url,
            occupation: r.occupation,
            organization: r.organization,
            designation: r.designation,
            work_location: r.work_location,
            business_name: r.business_name,
            business_type: r.business_type,
            business_address: r.business_address,
            business_website: r.business_website,
            address: r.address,
            bio: r.bio,
            privacy: r.privacy || undefined,
            created_at: r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString(),
          }));

          // Purge legacy dummy accounts
          const dummyUsernames = ['exec', 'content', 'event', 'finance', 'contentmanager', 'eventmanager', 'financemanager', 'farhan', 'rahim', 'test'];
          const dummyEmails = ['exec@nanupuralumni.org', 'content@nanupuralumni.org', 'event@nanupuralumni.org', 'finance@nanupuralumni.org', 'farhan@example.com', 'rahim@example.com', 'test@gmail.com', 'admin@dizency.com'];

          remoteUsers = remoteUsers.filter(u => 
            !dummyUsernames.includes((u.username || '').toLowerCase()) &&
            !dummyEmails.includes((u.email || '').toLowerCase()) &&
            !(u.email || '').endsWith('@example.com')
          );

          if (this.pool && this.isSupabaseConnected) {
            try {
              await this.pool.query(
                `DELETE FROM public.users WHERE role != 'super_admin' AND (email LIKE '%@example.com' OR username IN ('exec', 'content', 'event', 'finance', 'farhan', 'rahim', 'test'))`
              );
            } catch (pErr: any) {
              console.warn('Database dummy purge note:', pErr.message);
            }
          }

          // Merge any existing local registered users so they are preserved
          let addedNew = false;
          for (const lu of (this.data.users || [])) {
            const found = remoteUsers.some(ru => ru.id === lu.id || (lu.email && ru.email?.toLowerCase() === lu.email?.toLowerCase()) || (lu.phone && ru.phone === lu.phone));
            if (!found) {
              remoteUsers.push(lu);
              addedNew = true;
            }
          }

          this.data.users = this.sanitizeAndDeduplicateUsers(remoteUsers);
          this.saveData();
          if (addedNew) {
            await this.persistKeyToSupabase('users', this.data.users);
          }
        } else if (this.data.users && this.data.users.length > 0) {
          console.log('Seeding users to Supabase...');
          await this.persistKeyToSupabase('users', this.data.users);
        }
      } catch (uErr: any) {
        console.warn('Users sync note:', uErr.message);
      }

      // 5. Hydrate Registrations (Purging any test/dummy registrations)
      try {
        if (this.pool && this.isSupabaseConnected) {
          try {
            await this.pool.query(
              `DELETE FROM public.payment_transactions 
               WHERE registration_id = ANY($1) 
                  OR registration_id = '' 
                  OR registration_id IS NULL`,
              [DUMMY_REG_IDS]
            );
            await this.pool.query(
              `DELETE FROM public.entry_tokens 
               WHERE registration_id = ANY($1) 
                  OR member_name = ANY($2) 
                  OR member_name ILIKE '%Audit Verification%' 
                  OR member_name ILIKE '%Test Alumnus%'`,
              [DUMMY_REG_IDS, DUMMY_REG_NAMES]
            );
            await this.pool.query(
              `DELETE FROM public.event_registrations 
               WHERE id = ANY($1) 
                  OR full_name = ANY($2) 
                  OR full_name ILIKE '%Audit Verification%' 
                  OR full_name ILIKE '%Test Alumnus%' 
                  OR full_name ILIKE '%Test Mail%'`,
              [DUMMY_REG_IDS, DUMMY_REG_NAMES]
            );
          } catch (delErr: any) {
            console.warn('Purge dummy registrations note:', delErr.message);
          }
        }

        const regRes = await this.pool.query('SELECT * FROM event_registrations ORDER BY created_at DESC');
        let remoteRegs: Registration[] = [];
        if (regRes.rows && regRes.rows.length > 0) {
          remoteRegs = regRes.rows
            .filter(r => !isDummyRegistration(r))
            .map(r => ({
              id: r.id,
              event_id: r.event_id || 'event-85th-anniversary',
              user_id: r.user_id || undefined,
              full_name: r.full_name,
              dob: r.dob,
              gender: r.gender,
              blood_group: r.blood_group,
              t_shirt_size: r.t_shirt_size,
              phone: r.phone,
              email: r.email,
              passing_year: r.passing_year,
              batch_id: r.batch_id,
              batch_name: r.passing_year ? `SSC Batch ${r.passing_year}` : r.batch_name,
              batch_name_bn: r.passing_year ? `এসএসসি ব্যাচ ${r.passing_year}` : r.batch_name_bn,
              fee_amount: Number(r.fee_amount) || 1000,
              currency: r.currency || 'BDT',
              payment_status: r.payment_status || 'pending',
              registration_status: r.registration_status || 'pending',
              payment_method: r.payment_method,
              token_id: r.token_id,
              token_code: r.token_code,
              checked_in: r.checked_in || false,
              checked_in_at: r.checked_in_at,
              created_at: r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString(),
              updated_at: r.updated_at ? new Date(r.updated_at).toISOString() : (r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString()),
            }));
        }

        // Merge any existing local non-dummy registered entries so they are preserved across reconnects
        let addedNewRegs = false;
        for (const lr of (this.data.registrations || [])) {
          if (isDummyRegistration(lr)) continue;
          const found = remoteRegs.some(rr => rr.id === lr.id || (lr.phone && rr.phone === lr.phone));
          if (!found) {
            remoteRegs.push(lr);
            addedNewRegs = true;
          }
        }

        this.data.registrations = remoteRegs;
        this.saveData();
        if (addedNewRegs) {
          await this.persistKeyToSupabase('registrations', this.data.registrations);
        }
      } catch (regErr: any) {
        console.warn('Registrations sync note:', regErr.message);
      }

      // 6. Hydrate Tokens
      try {
        const tokRes = await this.pool.query('SELECT * FROM entry_tokens');
        let remoteTokens: EntryToken[] = [];
        const validRegIds = new Set(this.data.registrations.map(r => r.id));
        if (tokRes.rows && tokRes.rows.length > 0) {
          remoteTokens = tokRes.rows
            .filter(t => 
              validRegIds.has(t.registration_id) &&
              !DUMMY_REG_IDS.includes(t.registration_id) && 
              !DUMMY_REG_NAMES.includes(t.member_name) &&
              !(t.member_name || '').includes('Audit Verification')
            )
            .map(t => ({
              id: t.id,
              token_code: t.token_code,
              registration_id: t.registration_id,
              event_id: t.event_id || 'event-85th-anniversary',
              member_name: t.member_name,
              batch_name: t.batch_name,
              batch_name_bn: t.batch_name_bn || undefined,
              qr_code_svg: t.qr_code_svg || '',
              status: t.status || 'active',
              checked_in: t.checked_in || false,
              checked_in_at: t.checked_in_at,
              created_at: t.created_at ? new Date(t.created_at).toISOString() : new Date().toISOString(),
            }));
        }

        let addedNewTokens = false;
        for (const lt of (this.data.tokens || [])) {
          if (!lt || !lt.id) continue;
          const found = remoteTokens.some(rt => rt.id === lt.id || (lt.token_code && rt.token_code === lt.token_code));
          if (!found && validRegIds.has(lt.registration_id)) {
            remoteTokens.push(lt);
            addedNewTokens = true;
          }
        }

        this.data.tokens = remoteTokens;
        this.saveData();
        if (addedNewTokens) {
          await this.persistKeyToSupabase('tokens', this.data.tokens);
        }
      } catch (tokErr: any) {
        console.warn('Tokens sync note:', tokErr.message);
      }

      // 7. Hydrate Notices
      try {
        const nRes = await this.pool.query('SELECT * FROM notices ORDER BY publish_date DESC');
        if (nRes.rows && nRes.rows.length > 0) {
          this.data.notices = nRes.rows.map(n => ({
            id: n.id,
            title_en: n.title_en,
            title_bn: n.title_bn,
            content_en: n.content_en,
            content_bn: n.content_bn,
            publish_date: n.publish_date ? new Date(n.publish_date).toISOString().split('T')[0] : '2026-01-01',
            is_featured: n.is_featured || false,
            is_active: n.is_active !== false,
          }));
        } else if (this.data.notices && this.data.notices.length > 0) {
          await this.persistKeyToSupabase('notices', this.data.notices);
        }
      } catch (nErr: any) {
        console.warn('Notices sync note:', nErr.message);
      }

      // 8. Hydrate News
      try {
        const nwRes = await this.pool.query('SELECT * FROM news_posts ORDER BY publish_date DESC');
        if (nwRes.rows && nwRes.rows.length > 0) {
          this.data.news = nwRes.rows.map(nw => ({
            id: nw.id,
            slug: nw.slug,
            title_en: nw.title_en,
            title_bn: nw.title_bn,
            content_en: nw.content_en,
            content_bn: nw.content_bn,
            category: nw.category || 'General',
            author: nw.author || 'Alumni Secretariat',
            publish_date: nw.publish_date ? new Date(nw.publish_date).toISOString().split('T')[0] : '2026-01-01',
            is_published: nw.is_published !== false,
            views: nw.views || 0,
          }));
        } else if (this.data.news && this.data.news.length > 0) {
          await this.persistKeyToSupabase('news', this.data.news);
        }
      } catch (nwErr: any) {
        console.warn('News sync note:', nwErr.message);
      }

      // 9. Hydrate Payment Transactions
      try {
        const payRes = await this.pool.query('SELECT * FROM payment_transactions ORDER BY created_at DESC');
        let remotePayments: PaymentTransaction[] = [];
        const validRegIds = new Set(this.data.registrations.map(r => r.id));
        if (payRes.rows && payRes.rows.length > 0) {
          remotePayments = payRes.rows
            .filter(p => p.registration_id && validRegIds.has(p.registration_id) && !DUMMY_REG_IDS.includes(p.registration_id))
            .map(p => ({
              id: p.id,
              registration_id: p.registration_id || '',
              transaction_id: p.transaction_id || `MANUAL-${Date.now()}`,
              gateway: p.gateway || 'bkash',
              method: p.method || 'Manual Payment',
              amount: Number(p.amount) || 0,
              currency: p.currency || 'BDT',
              status: p.status as PaymentStatus,
              sender_mobile: p.sender_mobile || undefined,
              token_code: p.token_code || undefined,
              verified_by: p.verified_by || undefined,
              notes: p.notes || undefined,
              verified_at: p.verified_at ? new Date(p.verified_at).toISOString() : undefined,
              gateway_ref: p.gateway_ref || undefined,
              gateway_response: p.gateway_response || undefined,
              failure_reason: p.failure_reason || undefined,
              created_at: p.created_at ? new Date(p.created_at).toISOString() : new Date().toISOString(),
            }));
        }

        let addedNewPayments = false;
        for (const lp of (this.data.payments || [])) {
          if (!lp || !lp.id) continue;
          const found = remotePayments.some(rp => rp.id === lp.id || (lp.transaction_id && rp.transaction_id === lp.transaction_id));
          if (!found && validRegIds.has(lp.registration_id)) {
            remotePayments.push(lp);
            addedNewPayments = true;
          }
        }

        this.data.payments = remotePayments;
        this.saveData();
        if (addedNewPayments) {
          await this.persistKeyToSupabase('payments', this.data.payments);
        }
      } catch (payErr: any) {
        console.warn('Payment transactions sync note:', payErr.message);
      }

      // 10. Hydrate Committee Members
      try {
        const cmRes = await this.pool.query('SELECT * FROM committee_members ORDER BY order_index ASC');
        if (cmRes.rows && cmRes.rows.length > 0) {
          console.log(`Loaded ${cmRes.rows.length} committee members from Supabase.`);
          const remoteCM: CommitteeMemberItem[] = cmRes.rows.map(cm => ({
            id: cm.id,
            committee_id: cm.committee_id || 'comm-ec-2026',
            user_id: cm.user_id || undefined,
            custom_name_en: cm.name_en,
            custom_name_bn: cm.name_bn,
            designation_en: cm.designation_en,
            designation_bn: cm.designation_bn,
            batch_year: cm.batch_year || undefined,
            photo_url: cm.photo_url || undefined,
            phone: cm.phone || undefined,
            email: cm.email || undefined,
            order_index: Number(cm.order_index) || 1,
            is_active: cm.is_active !== false,
          }));

          let addedNewCM = false;
          for (const lcm of (this.data.committee_members || [])) {
            const found = remoteCM.some(c => c.id === lcm.id);
            if (!found) {
              remoteCM.push(lcm);
              addedNewCM = true;
            }
          }
          this.data.committee_members = remoteCM;
          this.saveData();
          if (addedNewCM) {
            await this.persistKeyToSupabase('committee_members', this.data.committee_members);
          }
        } else if (this.data.committee_members && this.data.committee_members.length > 0) {
          await this.persistKeyToSupabase('committee_members', this.data.committee_members);
        }
      } catch (cmErr: any) {
        console.warn('Committee members sync note:', cmErr.message);
      }

      // Update local file cache
      this.saveData();
    } catch (err: any) {
      console.warn('Error syncing with Supabase:', err.message);
    }
  }

  public async syncSingleUser(u: any): Promise<void> {
    if (!this.pool || !this.isSupabaseConnected || !u || !u.id) return;
    const cleanEmail = (u.email || '').trim().toLowerCase();
    const cleanUsername = (u.username || '').trim().toLowerCase();

    try {
      // Find existing user by ID or by unique email or username
      const checkRes = await this.pool.query(
        `SELECT id, role, password_hash, email, username FROM users 
         WHERE id = $1 
            OR ($2 != '' AND LOWER(email) = $2)
            OR ($3 != '' AND LOWER(username) = $3)
         LIMIT 1`,
        [u.id, cleanEmail, cleanUsername]
      );

      if (checkRes.rows && checkRes.rows.length > 0) {
        const matched = checkRes.rows[0];
        const matchedId = matched.id;
        const effectiveRole = matched.role === 'super_admin' ? 'super_admin' : (u.role || matched.role || 'alumni_member');

        await this.pool.query(
          `UPDATE users SET
            username = COALESCE(NULLIF($2, ''), username),
            name = COALESCE(NULLIF($3, ''), name),
            name_bn = COALESCE(NULLIF($4, ''), name_bn),
            email = COALESCE(NULLIF($5, ''), email),
            phone = COALESCE(NULLIF($6, ''), phone),
            password_hash = COALESCE(NULLIF($7, ''), password_hash),
            role = $8::user_role,
            status = COALESCE(NULLIF($9, ''), status),
            passing_year = COALESCE($10, passing_year),
            batch = COALESCE(NULLIF($11, ''), batch),
            dob = COALESCE(NULLIF($12, ''), dob),
            gender = COALESCE(NULLIF($13, ''), gender),
            blood_group = COALESCE(NULLIF($14, ''), blood_group),
            photo_url = COALESCE(NULLIF($15, ''), photo_url),
            occupation = COALESCE(NULLIF($16, ''), occupation),
            organization = COALESCE(NULLIF($17, ''), organization),
            designation = COALESCE(NULLIF($18, ''), designation),
            work_location = COALESCE(NULLIF($19, ''), work_location),
            business_name = COALESCE(NULLIF($20, ''), business_name),
            business_type = COALESCE(NULLIF($21, ''), business_type),
            business_address = COALESCE(NULLIF($22, ''), business_address),
            business_website = COALESCE(NULLIF($23, ''), business_website),
            address = COALESCE(NULLIF($24, ''), address),
            bio = COALESCE(NULLIF($25, ''), bio),
            privacy = COALESCE($26, privacy),
            updated_at = NOW()
          WHERE id = $1`,
          [
            matchedId, u.username || matched.username || '', u.name, u.name_bn || '', u.email || matched.email || '', u.phone || '',
            u.password_hash || '', effectiveRole, u.status || 'active',
            u.passing_year || null, u.batch || '', u.dob || '', u.gender || '',
            u.blood_group || '', u.photo_url || '', u.occupation || '', u.organization || '',
            u.designation || '', u.work_location || '', u.business_name || '', u.business_type || '',
            u.business_address || '', u.business_website || '', u.address || '', u.bio || '',
            u.privacy ? (typeof u.privacy === 'string' ? u.privacy : JSON.stringify(u.privacy)) : null,
          ]
        );
      } else {
        await this.pool.query(
          `INSERT INTO users (
            id, username, name, name_bn, email, phone, password_hash, role, status,
            passing_year, batch, dob, gender, blood_group, photo_url,
            occupation, organization, designation, work_location,
            business_name, business_type, business_address, business_website,
            address, bio, privacy, created_at, updated_at
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, NOW(), NOW())
          ON CONFLICT (id) DO UPDATE SET
            username = EXCLUDED.username,
            name = EXCLUDED.name,
            name_bn = EXCLUDED.name_bn,
            email = EXCLUDED.email,
            phone = EXCLUDED.phone,
            password_hash = COALESCE(NULLIF(EXCLUDED.password_hash, ''), users.password_hash),
            role = CASE WHEN users.role = 'super_admin' THEN 'super_admin' ELSE EXCLUDED.role END,
            status = EXCLUDED.status,
            passing_year = EXCLUDED.passing_year,
            batch = EXCLUDED.batch,
            dob = EXCLUDED.dob,
            gender = EXCLUDED.gender,
            blood_group = EXCLUDED.blood_group,
            photo_url = EXCLUDED.photo_url,
            occupation = EXCLUDED.occupation,
            organization = EXCLUDED.organization,
            designation = EXCLUDED.designation,
            work_location = EXCLUDED.work_location,
            business_name = EXCLUDED.business_name,
            business_type = EXCLUDED.business_type,
            business_address = EXCLUDED.business_address,
            business_website = EXCLUDED.business_website,
            address = EXCLUDED.address,
            bio = EXCLUDED.bio,
            privacy = EXCLUDED.privacy,
            updated_at = NOW()`,
          [
            u.id,
            u.username || '',
            u.name,
            u.name_bn || '',
            u.email,
            u.phone || '',
            u.password_hash || '',
            u.role || 'alumni_member',
            u.status || 'active',
            u.passing_year || null,
            u.batch || '',
            u.dob || '',
            u.gender || '',
            u.blood_group || '',
            u.photo_url || '',
            u.occupation || '',
            u.organization || '',
            u.designation || '',
            u.work_location || '',
            u.business_name || '',
            u.business_type || '',
            u.business_address || '',
            u.business_website || '',
            u.address || '',
            u.bio || '',
            u.privacy ? (typeof u.privacy === 'string' ? u.privacy : JSON.stringify(u.privacy)) : null,
          ]
        );
      }
    } catch (pgErr: any) {
      if (pgErr.code === '23505') {
        console.warn(`[syncSingleUser] Handled unique constraint collision for ${u.email}:`, pgErr.message);
        try {
          if (cleanEmail) {
            await this.pool.query(
              `UPDATE users SET name = COALESCE(NULLIF($2, ''), name), phone = COALESCE(NULLIF($3, ''), phone), updated_at = NOW() WHERE LOWER(email) = $1`,
              [cleanEmail, u.name, u.phone || '']
            );
          }
        } catch {}
      } else {
        throw pgErr;
      }
    }
  }

  public async syncSingleRegistration(r: any): Promise<void> {
    if (!this.pool || !this.isSupabaseConnected || !r || !r.id) return;

    // Verify user exists or sync user first
    let userIdToInsert: string | null = null;
    if (r.user_id) {
      try {
        const uCheck = await this.pool.query('SELECT id FROM users WHERE id = $1', [r.user_id]);
        if (uCheck.rows && uCheck.rows.length > 0) {
          userIdToInsert = r.user_id;
        } else {
          // Check local users cache
          const localUser = (this.data.users || []).find(u => u.id === r.user_id);
          if (localUser) {
            await this.syncSingleUser(localUser);
            userIdToInsert = localUser.id;
          } else if (r.email || r.phone) {
            const altCheck = await this.pool.query(
              'SELECT id FROM users WHERE (email IS NOT NULL AND email = $1) OR (phone IS NOT NULL AND phone = $2) LIMIT 1',
              [r.email || '', r.phone || '']
            );
            if (altCheck.rows && altCheck.rows.length > 0) {
              userIdToInsert = altCheck.rows[0].id;
            }
          }
        }
      } catch {
        userIdToInsert = null;
      }
    }

    // Verify event exists
    let eventIdToInsert = r.event_id || 'event-85th-anniversary';
    try {
      const evCheck = await this.pool.query('SELECT id FROM events WHERE id = $1', [eventIdToInsert]);
      if (!evCheck.rows || evCheck.rows.length === 0) {
        await this.pool.query(`
          INSERT INTO events (id, slug, title_en, title_bn, event_date, venue_en, registration_fee, currency)
          VALUES ($1, '85th-anniversary', '85th Anniversary', '৮৫তম বার্ষিকী', '2027-01-16', 'School Grounds', 1000, 'BDT')
          ON CONFLICT (id) DO NOTHING
        `, [eventIdToInsert]);
      }
    } catch {}

    // Verify batch exists or set null
    let batchIdToInsert = r.batch_id || null;
    if (batchIdToInsert) {
      try {
        const bCheck = await this.pool.query('SELECT id FROM batches WHERE id = $1', [batchIdToInsert]);
        if (!bCheck.rows || bCheck.rows.length === 0) {
          batchIdToInsert = null;
        }
      } catch {
        batchIdToInsert = null;
      }
    }

    await this.pool.query(
      `INSERT INTO event_registrations (
        id, event_id, user_id, full_name, dob, gender, blood_group, t_shirt_size,
        phone, email, passing_year, batch_id, batch_name, batch_name_bn,
        fee_amount, currency, payment_status, registration_status, payment_method,
        token_id, token_code, checked_in, checked_in_at, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, NOW(), NOW())
      ON CONFLICT (id) DO UPDATE SET
        user_id = EXCLUDED.user_id,
        full_name = EXCLUDED.full_name,
        t_shirt_size = EXCLUDED.t_shirt_size,
        phone = EXCLUDED.phone,
        email = EXCLUDED.email,
        blood_group = EXCLUDED.blood_group,
        gender = EXCLUDED.gender,
        dob = EXCLUDED.dob,
        passing_year = EXCLUDED.passing_year,
        batch_name = EXCLUDED.batch_name,
        batch_name_bn = EXCLUDED.batch_name_bn,
        fee_amount = EXCLUDED.fee_amount,
        payment_status = EXCLUDED.payment_status,
        registration_status = EXCLUDED.registration_status,
        payment_method = EXCLUDED.payment_method,
        token_id = EXCLUDED.token_id,
        token_code = EXCLUDED.token_code,
        checked_in = EXCLUDED.checked_in,
        checked_in_at = EXCLUDED.checked_in_at,
        updated_at = NOW()`,
      [
        r.id,
        eventIdToInsert,
        userIdToInsert,
        r.full_name,
        r.dob || '1990-01-01',
        r.gender || 'male',
        r.blood_group || null,
        r.t_shirt_size || null,
        r.phone,
        r.email || '',
        r.passing_year || 2008,
        batchIdToInsert,
        r.batch_name || '',
        r.batch_name_bn || '',
        r.fee_amount || 1000,
        r.currency || 'BDT',
        r.payment_status || 'pending',
        r.registration_status || 'pending',
        r.payment_method || 'bKash',
        r.token_id || '',
        r.token_code || '',
        r.checked_in || false,
        r.checked_in_at || null,
      ]
    );
  }

  public async syncSingleToken(t: any): Promise<void> {
    if (!this.pool || !this.isSupabaseConnected || !t || !t.id) return;

    // Verify registration exists or sync registration first
    let regIdToInsert: string | null = null;
    if (t.registration_id) {
      try {
        const regCheck = await this.pool.query('SELECT id FROM event_registrations WHERE id = $1', [t.registration_id]);
        if (regCheck.rows && regCheck.rows.length > 0) {
          regIdToInsert = t.registration_id;
        } else {
          const localReg = (this.data.registrations || []).find(r => r.id === t.registration_id);
          if (localReg) {
            await this.syncSingleRegistration(localReg);
            regIdToInsert = localReg.id;
          }
        }
      } catch {
        regIdToInsert = null;
      }
    }

    let eventIdToInsert = t.event_id || 'event-85th-anniversary';
    try {
      const evCheck = await this.pool.query('SELECT id FROM events WHERE id = $1', [eventIdToInsert]);
      if (!evCheck.rows || evCheck.rows.length === 0) {
        await this.pool.query(`
          INSERT INTO events (id, slug, title_en, title_bn, event_date, venue_en, registration_fee, currency)
          VALUES ($1, '85th-anniversary', '85th Anniversary', '৮৫তম বার্ষিকী', '2027-01-16', 'School Grounds', 1000, 'BDT')
          ON CONFLICT (id) DO NOTHING
        `, [eventIdToInsert]);
      }
    } catch {}

    await this.pool.query(
      `INSERT INTO entry_tokens (id, token_code, registration_id, event_id, member_name, batch_name, status, checked_in, checked_in_at, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
       ON CONFLICT (id) DO UPDATE
       SET token_code = $2, registration_id = $3, member_name = $5, batch_name = $6, status = $7, checked_in = $8, checked_in_at = $9`,
      [t.id, t.token_code, regIdToInsert, eventIdToInsert, t.member_name, t.batch_name, t.status || 'active', t.checked_in || false, t.checked_in_at || null]
    );
  }

  public async syncSinglePayment(p: any): Promise<void> {
    if (!this.pool || !this.isSupabaseConnected || !p || !p.id) return;

    // Verify registration exists or sync registration first
    let regIdToInsert: string | null = null;
    if (p.registration_id) {
      try {
        const regCheck = await this.pool.query('SELECT id FROM event_registrations WHERE id = $1', [p.registration_id]);
        if (regCheck.rows && regCheck.rows.length > 0) {
          regIdToInsert = p.registration_id;
        } else {
          const localReg = (this.data.registrations || []).find(r => r.id === p.registration_id);
          if (localReg) {
            await this.syncSingleRegistration(localReg);
            regIdToInsert = localReg.id;
          }
        }
      } catch {
        regIdToInsert = null;
      }
    }

    const txId = p.transaction_id || `TRX-${Date.now()}`;
    const gateway = p.gateway || 'bkash';
    const method = p.method || 'Manual Payment';
    const amount = Number(p.amount) || 1000;
    const currency = p.currency || 'BDT';
    const status = p.status || 'pending';
    const senderMobile = p.sender_mobile || null;
    const tokenCode = p.token_code || null;
    const verifiedBy = p.verified_by || null;
    const notes = p.notes || null;
    const verifiedAt = p.verified_at ? new Date(p.verified_at).toISOString() : null;
    const gatewayRef = p.gateway_ref || null;
    const gatewayResponse = p.gateway_response ? JSON.stringify(p.gateway_response) : null;
    const failureReason = p.failure_reason || null;
    const createdAt = p.created_at ? new Date(p.created_at).toISOString() : new Date().toISOString();

    await this.pool.query(
      `INSERT INTO payment_transactions (
        id, registration_id, transaction_id, gateway, method, amount, currency, status,
        sender_mobile, token_code, verified_by, notes, verified_at,
        gateway_ref, gateway_response, failure_reason, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
      ON CONFLICT (id) DO UPDATE SET
        registration_id = EXCLUDED.registration_id,
        transaction_id = EXCLUDED.transaction_id,
        gateway = EXCLUDED.gateway,
        method = EXCLUDED.method,
        amount = EXCLUDED.amount,
        currency = EXCLUDED.currency,
        status = EXCLUDED.status,
        sender_mobile = EXCLUDED.sender_mobile,
        token_code = EXCLUDED.token_code,
        verified_by = EXCLUDED.verified_by,
        notes = EXCLUDED.notes,
        verified_at = EXCLUDED.verified_at,
        gateway_ref = EXCLUDED.gateway_ref,
        gateway_response = EXCLUDED.gateway_response,
        failure_reason = EXCLUDED.failure_reason`,
      [
        p.id,
        regIdToInsert,
        txId,
        gateway,
        method,
        amount,
        currency,
        status,
        senderMobile,
        tokenCode,
        verifiedBy,
        notes,
        verifiedAt,
        gatewayRef,
        gatewayResponse,
        failureReason,
        createdAt,
      ]
    );
  }

  public async syncSingleCommitteeMember(cm: any): Promise<void> {
    if (!this.pool || !this.isSupabaseConnected || !cm || !cm.id) return;

    await this.pool.query(
      `INSERT INTO committee_members (
        id, committee_id, user_id, name_en, name_bn, designation_en, designation_bn,
        batch_year, photo_url, phone, email, tenure, order_index, is_active, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NOW())
      ON CONFLICT (id) DO UPDATE SET
        committee_id = EXCLUDED.committee_id,
        user_id = EXCLUDED.user_id,
        name_en = EXCLUDED.name_en,
        name_bn = EXCLUDED.name_bn,
        designation_en = EXCLUDED.designation_en,
        designation_bn = EXCLUDED.designation_bn,
        batch_year = EXCLUDED.batch_year,
        photo_url = EXCLUDED.photo_url,
        phone = EXCLUDED.phone,
        email = EXCLUDED.email,
        tenure = EXCLUDED.tenure,
        order_index = EXCLUDED.order_index,
        is_active = EXCLUDED.is_active`,
      [
        cm.id,
        cm.committee_id || 'comm-ec-2026',
        cm.user_id || null,
        cm.custom_name_en || cm.name_en || cm.name || 'Member',
        cm.custom_name_bn || cm.name_bn || cm.name_en || 'সদস্য',
        cm.designation_en || 'Member',
        cm.designation_bn || 'সদস্য',
        cm.batch_year || null,
        cm.photo_url || null,
        cm.phone || null,
        cm.email || null,
        cm.tenure || '2026-2028',
        cm.order_index || 1,
        cm.is_active !== false,
      ]
    );
  }

  public async persistKeyToSupabase(key: string, value: any) {
    if (!this.pool || !this.isSupabaseConnected) return;
    try {
      // 1. General Site Settings table entry
      await this.pool.query(
        `INSERT INTO site_settings (key, value, updated_at) 
         VALUES ($1, $2, NOW()) 
         ON CONFLICT (key) 
         DO UPDATE SET value = $2, updated_at = NOW()`,
        [key, JSON.stringify(value)]
      );

      // 2. Real table synchronization for users
      if (key === 'users' && Array.isArray(value)) {
        for (const u of value) {
          try {
            await this.syncSingleUser(u);
          } catch (uErr: any) {
            console.warn(`User row sync error (${u.email}):`, uErr.message);
          }
        }
      }

      // 3. Real table synchronization for registrations
      if (key === 'registrations' && Array.isArray(value)) {
        for (const r of value) {
          try {
            await this.syncSingleRegistration(r);
          } catch (rErr: any) {
            console.warn(`Registration row sync error (${r.id}):`, rErr.message);
          }
        }
      }

      // 4. Real table synchronization for batches
      if (key === 'batches' && Array.isArray(value)) {
        for (const b of value) {
          try {
            await this.pool.query(
              `INSERT INTO batches (id, name_en, name_bn, passing_year, batch_number, representative_name, representative_phone, is_active)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
               ON CONFLICT (id) DO UPDATE
               SET name_en = $2, name_bn = $3, passing_year = $4, batch_number = $5, representative_name = $6, representative_phone = $7, is_active = $8`,
              [b.id, b.name_en, b.name_bn, b.passing_year, b.batch_number, b.representative_name, b.representative_phone, b.is_active]
            );
          } catch (bErr: any) {
            console.warn(`Batch row sync error (${b.id}):`, bErr.message);
          }
        }
      }

      // 5. Real table synchronization for tokens
      if (key === 'tokens' && Array.isArray(value)) {
        for (const t of value) {
          try {
            await this.syncSingleToken(t);
          } catch (tErr: any) {
            console.warn(`Token row sync error (${t.id}):`, tErr.message);
          }
        }
      }

      // 6. Dedicated sync for notices
      if (key === 'notices' && Array.isArray(value)) {
        for (const n of value) {
          try {
            await this.pool.query(
              `INSERT INTO notices (id, title_en, title_bn, content_en, content_bn, publish_date, is_featured, is_active)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
               ON CONFLICT (id) DO UPDATE
               SET title_en = $2, title_bn = $3, content_en = $4, content_bn = $5, is_featured = $7, is_active = $8`,
              [n.id, n.title_en, n.title_bn, n.content_en, n.content_bn, n.publish_date || '2026-01-01', n.is_featured || false, n.is_active !== false]
            );
          } catch (nErr: any) {
            console.warn(`Notice row sync error (${n.id}):`, nErr.message);
          }
        }
      }

      // 7. Dedicated sync for news
      if (key === 'news' && Array.isArray(value)) {
        for (const nw of value) {
          try {
            await this.pool.query(
              `INSERT INTO news_posts (id, slug, title_en, title_bn, content_en, content_bn, category, publish_date, is_published, views)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
               ON CONFLICT (id) DO UPDATE
               SET slug = $2, title_en = $3, title_bn = $4, content_en = $5, content_bn = $6, is_published = $9, views = $10`,
              [nw.id, nw.slug, nw.title_en, nw.title_bn, nw.content_en, nw.content_bn, nw.category || 'General', nw.publish_date || '2026-01-01', nw.is_published !== false, nw.views || 0]
            );
          } catch (nwErr: any) {
            console.warn(`News row sync error (${nw.id}):`, nwErr.message);
          }
        }
      }

      // 8. Dedicated sync for audit logs
      if (key === 'audit_logs' && Array.isArray(value)) {
        const recentLogs = value.slice(-20);
        for (const l of recentLogs) {
          try {
            await this.pool.query(
              `INSERT INTO audit_logs (id, user_name, user_email, action, entity, details, ip, created_at)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
               ON CONFLICT (id) DO NOTHING`,
              [l.id, l.user_name || 'Admin', l.user_email || 'admin@nanupuralumni.org', l.action, l.entity || 'System', l.details || '', l.ip || null, l.created_at || new Date().toISOString()]
            );
          } catch {}
        }
      }

      // 9. Dedicated sync for menus
      if (key === 'menus' && Array.isArray(value)) {
        try {
          await this.pool.query('DELETE FROM menus');
          for (const m of value) {
            await this.pool.query(
              `INSERT INTO menus (id, label_en, label_bn, url, target, order_index, parent_id, is_active, children, created_at)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())`,
              [
                m.id,
                m.label_en || '',
                m.label_bn || '',
                m.url || '',
                m.target || '_self',
                m.order || 1,
                m.parent_id || null,
                m.is_active !== false,
                JSON.stringify(m.children || []),
              ]
            );
          }
        } catch (mErr: any) {
          // Table sync note
        }
      }

      // 10. Dedicated sync for pages
      if (key === 'pages' && Array.isArray(value)) {
        try {
          for (const p of value) {
            await this.pool.query(
              `INSERT INTO pages (id, slug, title_en, title_bn, status, sections, updated_at)
               VALUES ($1, $2, $3, $4, $5, $6, NOW())
               ON CONFLICT (id) DO UPDATE 
               SET slug = $2, title_en = $3, title_bn = $4, status = $5, sections = $6, updated_at = NOW()`,
              [
                p.id,
                p.slug,
                p.title_en || '',
                p.title_bn || '',
                p.status || 'published',
                JSON.stringify(p.sections || []),
              ]
            );
          }
        } catch (pErr: any) {
          // Table sync note
        }
      }

      // 11. Dedicated sync for payments
      if (key === 'payments' && Array.isArray(value)) {
        for (const p of value) {
          try {
            await this.syncSinglePayment(p);
          } catch (pErr: any) {
            console.warn(`Payment row sync error (${p.id}):`, pErr.message);
          }
        }
      }

      // 12. Dedicated sync for committee members
      if (key === 'committee_members' && Array.isArray(value)) {
        for (const cm of value) {
          try {
            await this.syncSingleCommitteeMember(cm);
          } catch (cmErr: any) {
            console.warn(`Committee member row sync error (${cm.id}):`, cmErr.message);
          }
        }
      }
    } catch (err: any) {
      console.warn(`Supabase background persistence note for key ${key}:`, err.message);
    }
  }

  public async deleteRecord(table: string, id: string): Promise<void> {
    try {
      if (table === 'pages') await portableDb.deletePage(id);
      else if (table === 'news') await portableDb.deleteNews(id);
      else if (table === 'notices') await portableDb.deleteNotice(id);
      else if (table === 'committee_members') await portableDb.deleteCommitteeMember(id);
      else if (table === 'batches') await portableDb.deleteBatch(id);
      else if (table === 'offline_centers') await portableDb.deleteOfflineCenter(id);
      else if (table === 'registrations') await portableDb.deleteRegistration(id);
      else if (table === 'tokens') await portableDb.deleteToken(id);
      else if (table === 'payments') await portableDb.deletePayment(id);
      else if (table === 'users') await portableDb.deleteUser(id);

      if (this.pool && this.isSupabaseConnected) {
        let targetTable = table;
        if (table === 'registrations') targetTable = 'event_registrations';
        if (table === 'tokens') targetTable = 'entry_tokens';
        if (table === 'news') targetTable = 'news_posts';
        if (table === 'payments') targetTable = 'payment_transactions';
        if (table === 'committee_members') targetTable = 'committee_members';

        await this.pool.query(`DELETE FROM public.${targetTable} WHERE id = $1`, [id]);
      }
    } catch (err: any) {
      console.warn(`Delete record error (${table} ${id}):`, err.message);
    }
  }

  private loadInitialData(): DatabaseSchema {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        const resolved: DatabaseSchema = {
          batches: parsed.batches || initialBatches,
          events: parsed.events || [initialEvent],
          gates: parsed.gates || initialGates,
          school_info: parsed.school_info || initialSchoolInfo,
          association_info: parsed.association_info || initialAssociationInfo,
          committee: parsed.committee || initialCommittee,
          committees: parsed.committees || initialCommittees,
          committee_members: parsed.committee_members || initialCommitteeMembers,
          committee_designations: parsed.committee_designations || initialDesignations,
          offline_centers: parsed.offline_centers || initialOfflineCenters,
          notices: parsed.notices || initialNotices,
          news: parsed.news || initialNews,
          media: parsed.media || [
            {
              id: 'med-1',
              name: 'nash-school-building.jpg',
              url: 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=1000&q=80',
              type: 'image',
              size: '1.2 MB',
              created_at: new Date().toISOString(),
            },
          ],
          global_settings: parsed.global_settings || initialGlobalSettings,
          header_config: parsed.header_config || initialHeaderConfig,
          top_bar_config: parsed.top_bar_config || initialTopBarConfig,
          menus: parsed.menus || initialMenus,
          footer_config: parsed.footer_config || initialFooterConfig,
          pages: parsed.pages || initialPages,
          faqs: parsed.faqs || initialFAQs,
          payment_gateways: parsed.payment_gateways || initialPaymentGateways,
          registration_config: (() => {
            const cfg = parsed.registration_config ? { ...initialRegistrationConfig, ...parsed.registration_config } : initialRegistrationConfig;
            if (!cfg.max_image_size_mb) {
              cfg.max_image_size_mb = 1.5;
            }
            if (!Array.isArray(cfg.image_accepted_formats) || cfg.image_accepted_formats.length === 0) {
              cfg.image_accepted_formats = ['image/jpeg', 'image/png', 'image/webp'];
            }
            return cfg;
          })(),
          registration_confirmation_config: parsed.registration_confirmation_config
            ? { ...initialRegistrationConfirmationConfig, ...parsed.registration_confirmation_config }
            : initialRegistrationConfirmationConfig,
          settings_table: (() => {
            let list: SettingItem[] = Array.isArray(parsed.settings_table)
              ? [...parsed.settings_table]
              : [...initialSettingsTable];
            if (!list.some(s => s.key === 'registration_image_max_size')) {
              list.unshift({
                id: 1,
                key: 'registration_image_max_size',
                value: '1.5',
                group: 'registration',
                type: 'numeric',
                description: 'Maximum allowed registration photograph file size in Megabytes (MB). Default: 1.5MB.',
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
              });
            }
            return list;
          })(),
          token_format_config: parsed.token_format_config || initialTokenFormatConfig,
          batch_config: parsed.batch_config || initialBatchConfig,
          roles: parsed.roles || initialRoles,
          settings: parsed.settings || {
            ...initialGlobalSettings,
            registration_fee: parsed.registration_config?.fee_amount || 1000,
            currency: 'BDT',
            registration_open: true,
            registration_deadline: '2026-12-31',
            current_event_id: 'event-85th-anniversary',
            batch_calc_rule: '2008_base_65',
            batch_base_year: 2008,
            payment_test_mode: true,
            payment_bkash_enabled: true,
            payment_nagad_enabled: true,
            payment_sslcommerz_enabled: true,
          },
          users: (() => {
            const existing = parsed.users || [];
            const dummyUsernames = ['exec', 'content', 'event', 'finance', 'contentmanager', 'eventmanager', 'financemanager', 'farhan', 'rahim', 'test'];
            const dummyEmails = ['exec@nanupuralumni.org', 'content@nanupuralumni.org', 'event@nanupuralumni.org', 'finance@nanupuralumni.org', 'farhan@example.com', 'rahim@example.com', 'test@gmail.com', 'admin@dizency.com'];

            let filtered = existing.filter((u: any) => 
              !dummyUsernames.includes((u.username || '').toLowerCase()) &&
              !dummyEmails.includes((u.email || '').toLowerCase()) &&
              !(u.email || '').endsWith('@example.com')
            );

            return filtered;
          })(),
          registrations: (() => {
            const raw = parsed.registrations || [];
            return raw.filter((r: any) => !isDummyRegistration(r));
          })(),
          payments: (() => {
            const raw = parsed.payments || [];
            return raw.filter((p: any) => p.registration_id && !DUMMY_REG_IDS.includes(p.registration_id));
          })(),
          tokens: (() => {
            const raw = parsed.tokens || [];
            return raw.filter((t: any) => 
              !DUMMY_REG_IDS.includes(t.registration_id) && 
              !DUMMY_REG_NAMES.includes(t.member_name) &&
              !(t.member_name || '').includes('Audit Verification')
            );
          })(),
          audit_logs: parsed.audit_logs || [],
          program_schedule: parsed.program_schedule || initialProgramSchedule,
          registration_form_fields: (() => {
            let fields = parsed.registration_form_fields || initialRegistrationFields;
            if (Array.isArray(fields) && !fields.some((f: any) => f.name === 't_shirt_size')) {
              const defaultTShirt = initialRegistrationFields.find(f => f.name === 't_shirt_size');
              if (defaultTShirt) {
                fields = [...fields, defaultTShirt].sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
              }
            }
            return fields;
          })(),
          hero_config: parsed.hero_config || initialHeroConfig,
          mail_settings: parsed.mail_settings || initialMailSettings,
        };
        this.saveData(resolved);
        return resolved;
      }
    } catch (e) {
      console.error('Error loading db.json, using defaults:', e);
    }

    const initial: DatabaseSchema = {
      batches: initialBatches,
      events: [initialEvent],
      gates: initialGates,
      school_info: initialSchoolInfo,
      association_info: initialAssociationInfo,
      committee: initialCommittee,
      committees: initialCommittees,
      committee_members: initialCommitteeMembers,
      committee_designations: initialDesignations,
      offline_centers: initialOfflineCenters,
      notices: initialNotices,
      news: initialNews,
      media: [
        {
          id: 'med-1',
          name: 'nash-school-building.jpg',
          url: 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=1000&q=80',
          type: 'image',
          size: '1.2 MB',
          created_at: new Date().toISOString(),
        },
        {
          id: 'med-2',
          name: '85th-anniversary-poster.jpg',
          url: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1600&q=80',
          type: 'image',
          size: '2.4 MB',
          created_at: new Date().toISOString(),
        },
      ],
      global_settings: initialGlobalSettings,
      header_config: initialHeaderConfig,
      top_bar_config: initialTopBarConfig,
      menus: initialMenus,
      footer_config: initialFooterConfig,
      pages: initialPages,
      faqs: initialFAQs,
      payment_gateways: initialPaymentGateways,
      registration_config: initialRegistrationConfig,
      registration_confirmation_config: initialRegistrationConfirmationConfig,
      settings_table: initialSettingsTable,
      token_format_config: initialTokenFormatConfig,
      batch_config: initialBatchConfig,
      roles: initialRoles,
      settings: {
        ...initialGlobalSettings,
        registration_fee: 1000,
        currency: 'BDT',
        registration_open: true,
        registration_deadline: '2026-12-31',
        current_event_id: 'event-85th-anniversary',
        batch_calc_rule: '2008_base_65',
        batch_base_year: 2008,
        payment_test_mode: true,
        payment_bkash_enabled: true,
        payment_nagad_enabled: true,
        payment_sslcommerz_enabled: true,
      },
      users: initialUsers,
      registrations: initialRegistrations,
      payments: [
        {
          id: 'pay-1001',
          registration_id: 'REG-85-1001',
          transaction_id: 'TRX-BKASH-891234',
          gateway: 'bkash',
          method: 'bKash Mobile App',
          amount: 1000,
          currency: 'BDT',
          status: 'paid',
          gateway_ref: 'BKASH_REF_981721',
          created_at: '2026-03-01T10:18:00Z',
        },
        {
          id: 'pay-1002',
          registration_id: 'REG-85-1002',
          transaction_id: 'TRX-NAGAD-441209',
          gateway: 'nagad',
          method: 'Nagad Gateway',
          amount: 1000,
          currency: 'BDT',
          status: 'paid',
          gateway_ref: 'NAGAD_REF_110292',
          created_at: '2026-03-02T14:25:00Z',
        },
      ],
      tokens: initialTokens,
      audit_logs: [
        {
          id: 'log-1',
          user_name: 'Chief Admin (NASH IT)',
          user_email: 'admin@nanupuralumni.org',
          action: 'INITIALIZE_SYSTEM',
          entity: 'System',
          details: 'Initialized 85th Anniversary CMS Platform with database-driven WordPress-style architecture and 2008=65th batch baseline.',
          ip: '127.0.0.1',
          created_at: '2026-01-01T00:00:00Z',
        },
      ],
      program_schedule: initialProgramSchedule,
      registration_form_fields: initialRegistrationFields,
      hero_config: initialHeroConfig,
      mail_settings: initialMailSettings,
    };

    this.saveData(initial);
    return initial;
  }

  private saveData(snapshot?: DatabaseSchema) {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const toWrite = snapshot || this.data;
      fs.writeFileSync(DB_FILE, JSON.stringify(toWrite, null, 2), 'utf-8');
    } catch (e) {
      console.error('Error saving db.json:', e);
    }
  }

  public sanitizeAndDeduplicateUsers(users: any[]): any[] {
    if (!Array.isArray(users)) return [];

    const dummyUsernames = ['exec', 'content', 'event', 'finance', 'contentmanager', 'eventmanager', 'financemanager', 'farhan', 'rahim', 'test'];
    const dummyEmails = ['exec@nanupuralumni.org', 'content@nanupuralumni.org', 'event@nanupuralumni.org', 'finance@nanupuralumni.org', 'farhan@example.com', 'rahim@example.com', 'test@gmail.com', 'admin@dizency.com'];

    // 1. Filter out dummy accounts
    const filtered = users.filter(u =>
      u.role === 'super_admin' || (
        !dummyUsernames.includes((u.username || '').toLowerCase()) &&
        !dummyEmails.includes((u.email || '').toLowerCase()) &&
        !(u.email || '').endsWith('@example.com') &&
        !(u.email || '').endsWith('@example.org') &&
        !(u.email || '').includes('alumni_1791') &&
        !(u.name || '').includes('Audit Verification') &&
        !(u.name || '').includes('Test Alumnus') &&
        u.name !== 'Test Mail' &&
        u.username !== 'dup1'
      )
    );

    // 2. Deduplicate by email and id
    const result: any[] = [];
    const emailIndexMap = new Map<string, number>();
    const idSet = new Set<string>();

    for (const u of filtered) {
      if (!u || !u.id) continue;
      const cleanEmail = (u.email || '').trim().toLowerCase();

      // If email exists and was already seen in this collection
      if (cleanEmail && emailIndexMap.has(cleanEmail)) {
        const existingIdx = emailIndexMap.get(cleanEmail)!;
        const existingUser = result[existingIdx];

        // Super admin takes precedence; merge attributes
        if (u.role === 'super_admin' || (u.role === 'admin' && existingUser.role !== 'super_admin')) {
          result[existingIdx] = {
            ...existingUser,
            ...u,
            role: u.role === 'super_admin' ? 'super_admin' : (existingUser.role === 'super_admin' ? 'super_admin' : u.role),
            password_hash: u.password_hash || existingUser.password_hash,
          };
        } else {
          // Keep existing, merge missing non-empty fields from u
          for (const [key, val] of Object.entries(u)) {
            if (val !== undefined && val !== null && val !== '' && ((existingUser as any)[key] === undefined || (existingUser as any)[key] === null || (existingUser as any)[key] === '')) {
              (existingUser as any)[key] = val;
            }
          }
        }
        continue;
      }

      if (idSet.has(u.id)) {
        continue;
      }

      idSet.add(u.id);
      if (cleanEmail) {
        emailIndexMap.set(cleanEmail, result.length);
      }
      result.push({ ...u });
    }

    return result;
  }

  public get<K extends keyof DatabaseSchema>(key: K): DatabaseSchema[K] {
    if (key === 'users') {
      return this.sanitizeAndDeduplicateUsers(this.data.users || []) as DatabaseSchema[K];
    }
    return this.data[key];
  }

  public async setAsync<K extends keyof DatabaseSchema>(key: K, value: DatabaseSchema[K]): Promise<void> {
    if (key === 'users' && Array.isArray(value)) {
      value = this.sanitizeAndDeduplicateUsers(value) as DatabaseSchema[K];
    }
    this.data[key] = value;
    this.saveData();

    // 1. Unified portableDb collection and setting persistence (MySQL & PostgreSQL)
    if (Array.isArray(value)) {
      await portableDb.syncCollection(key as string, value as any[]);
    }
    await portableDb.saveSetting(key as string, value);

    // 2. Direct PostgreSQL pool sync if active
    await this.persistKeyToSupabase(key as string, value);
  }

  public set<K extends keyof DatabaseSchema>(key: K, value: DatabaseSchema[K]) {
    if (key === 'users' && Array.isArray(value)) {
      value = this.sanitizeAndDeduplicateUsers(value) as DatabaseSchema[K];
    }
    this.data[key] = value;
    this.saveData();

    // Fire unified async persistence
    this.setAsync(key, value).catch(err => {
      console.warn(`[DatabaseEngine] Async persistence error for ${String(key)}:`, err.message);
    });

    // Bidirectional sync: If registration_config updated with max_image_size_mb, sync settings_table
    if (key === 'registration_config' && (value as any)?.max_image_size_mb) {
      const mbVal = String((value as any).max_image_size_mb);
      this.setSetting('registration_image_max_size', mbVal, 'registration', 'Maximum allowed registration photograph file size in Megabytes (MB). Default: 1.5MB.', 'numeric').catch(() => {});
    }
  }

  public getAllSettings(): SettingItem[] {
    if (!this.data.settings_table) {
      this.data.settings_table = [...initialSettingsTable];
    }
    return this.data.settings_table;
  }

  public getSetting(key: string): string | null {
    const table = this.getAllSettings();
    const found = table.find(s => s.key === key);
    return found ? found.value : null;
  }

  public async setSetting(
    key: string,
    value: string,
    group: string = 'general',
    description?: string,
    type: string = 'string'
  ): Promise<SettingItem> {
    if (!this.data.settings_table) {
      this.data.settings_table = [...initialSettingsTable];
    }
    const existingIdx = this.data.settings_table.findIndex(s => s.key === key);
    const now = new Date().toISOString();
    let item: SettingItem;

    if (existingIdx >= 0) {
      item = {
        ...this.data.settings_table[existingIdx],
        value,
        group: group || this.data.settings_table[existingIdx].group || 'general',
        description: description || this.data.settings_table[existingIdx].description,
        type: type || this.data.settings_table[existingIdx].type || 'string',
        updated_at: now,
      };
      this.data.settings_table[existingIdx] = item;
    } else {
      item = {
        id: Date.now(),
        key,
        value,
        group,
        type: type || (isNaN(Number(value)) ? 'string' : 'numeric'),
        description: description || '',
        created_at: now,
        updated_at: now,
      };
      this.data.settings_table.push(item);
    }
    this.saveData();

    // Persist to underlying database settings table
    try {
      await portableDb.saveSettingRecord(key, value, group, item.type, description);
    } catch (e: any) {
      console.warn(`[DatabaseEngine] Could not persist to settings table:`, e.message);
    }

    // Two-way synchronization for registration_image_max_size
    if (key === 'registration_image_max_size') {
      const num = parseFloat(value);
      if (!isNaN(num) && num > 0) {
        if (!this.data.registration_config) {
          this.data.registration_config = { ...initialRegistrationConfig };
        }
        this.data.registration_config.max_image_size_mb = num;
        this.saveData();
      }
    }

    return item;
  }


  public logAudit(
    user_name: string,
    user_email: string,
    action: string,
    entity: string,
    details: string,
    ip: string = '127.0.0.1'
  ) {
    const log: AuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      user_name,
      user_email,
      action,
      entity,
      details,
      ip,
      created_at: new Date().toISOString(),
    };
    if (!this.data.audit_logs) {
      this.data.audit_logs = [];
    }
    this.data.audit_logs.unshift(log);
    if (this.data.audit_logs.length > 300) {
      this.data.audit_logs = this.data.audit_logs.slice(0, 300);
    }
    this.saveData();
    this.persistKeyToSupabase('audit_logs', this.data.audit_logs);
  }

  public getTableStats(): Record<string, number> {
    return {
      users: (this.data.users || []).length,
      registrations: (this.data.registrations || []).length,
      batches: (this.data.batches || []).length,
      events: (this.data.events || []).length,
      tokens: (this.data.tokens || []).length,
      notices: (this.data.notices || []).length,
      news: (this.data.news || []).length,
      committee: (this.data.committee || []).length,
      audit_logs: (this.data.audit_logs || []).length,
    };
  }

  public async getUserByCredential(credential: string): Promise<User | null> {
    if (!credential) return null;
    const clean = credential.trim().toLowerCase();

    // 1. Check in-memory store first
    const users = this.data.users || [];
    const memoryMatch = users.find(u =>
      (u.email && u.email.toLowerCase() === clean) ||
      (u.username && u.username.toLowerCase() === clean) ||
      (u.phone && u.phone.trim() === credential.trim())
    );
    if (memoryMatch) return memoryMatch;

    // 2. Query Supabase directly if connected
    if (this.pool && this.isSupabaseConnected) {
      try {
        const res = await this.pool.query(
          'SELECT * FROM public.users WHERE LOWER(email) = $1 OR LOWER(username) = $1 OR phone = $2 LIMIT 1',
          [clean, credential.trim()]
        );
        if (res.rows && res.rows.length > 0) {
          const r = res.rows[0];
          const fetchedUser: User = {
            id: r.id,
            username: r.username || (r.email ? r.email.split('@')[0] : 'user'),
            name: r.name,
            name_bn: r.name_bn || undefined,
            email: r.email,
            phone: r.phone,
            password_hash: r.password_hash,
            role: r.role || 'alumni_member',
            status: r.status || (r.is_active ? 'active' : 'inactive'),
            passing_year: r.passing_year,
            batch: r.batch,
            dob: r.dob,
            gender: r.gender,
            blood_group: r.blood_group,
            photo_url: r.photo_url || r.avatar_url,
            occupation: r.occupation,
            organization: r.organization,
            designation: r.designation,
            work_location: r.work_location,
            address: r.address,
            bio: r.bio,
            created_at: r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString(),
          };
          this.data.users.push(fetchedUser);
          return fetchedUser;
        }
      } catch (err: any) {
        console.warn('Direct user lookup warning:', err.message);
      }
    }

    return null;
  }

  public async updateUserPassword(userId: string, newHash: string): Promise<boolean> {
    const users = this.data.users || [];
    const uIndex = users.findIndex(u => u.id === userId);
    if (uIndex !== -1) {
      users[uIndex].password_hash = newHash;
      this.set('users', users);
    }
    if (this.pool && this.isSupabaseConnected) {
      try {
        await this.pool.query('UPDATE public.users SET password_hash = $1 WHERE id = $2', [newHash, userId]);
        return true;
      } catch (err: any) {
        console.warn('Update password in Supabase error:', err.message);
      }
    }
    return true;
  }

  public exportAsJSON(): string {
    return JSON.stringify(
      {
        metadata: {
          system: 'Nanupur Abu Sobhan High School Alumni Portal',
          celebration: 'Historic 85th Anniversary Celebration & Grand Reunion 2027',
          exported_at: new Date().toISOString(),
          version: '2.0.0',
          environment: process.env.NODE_ENV || 'production',
          table_counts: this.getTableStats(),
        },
        data: this.data,
      },
      null,
      2
    );
  }

  public exportRegistrationsCSV(): string {
    const registrations = this.data.registrations || [];
    const headers = [
      'Registration ID',
      'Full Name',
      'Passing Year',
      'Batch',
      'T-Shirt Size',
      'Phone',
      'Email',
      'Gender',
      'Blood Group',
      'Fee Amount',
      'Currency',
      'Payment Status',
      'Payment Method',
      'Registration Status',
      'Token Code',
      'Checked In',
      'Checked In At',
      'Registered At',
    ];

    const escapeCsv = (val: any) => {
      if (val === null || val === undefined) return '""';
      const str = String(val).replace(/"/g, '""');
      return `"${str}"`;
    };

    const rows = registrations.map(r => [
      escapeCsv(r.id),
      escapeCsv(r.full_name),
      escapeCsv(r.passing_year),
      escapeCsv(r.batch_name || `Batch ${r.passing_year}`),
      escapeCsv(r.t_shirt_size || ''),
      escapeCsv(r.phone),
      escapeCsv(r.email || ''),
      escapeCsv(r.gender || ''),
      escapeCsv(r.blood_group || ''),
      escapeCsv(r.fee_amount || 1000),
      escapeCsv(r.currency || 'BDT'),
      escapeCsv(r.payment_status || 'pending'),
      escapeCsv(r.payment_method || ''),
      escapeCsv(r.registration_status || 'pending'),
      escapeCsv(r.token_code || ''),
      escapeCsv(r.checked_in ? 'YES' : 'NO'),
      escapeCsv(r.checked_in_at || ''),
      escapeCsv(r.created_at || ''),
    ]);

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
  }

  public exportAsSQL(dialect: 'postgres' | 'mysql' = 'postgres'): string {
    const timestamp = new Date().toISOString();
    const isMySQL = dialect === 'mysql';
    const sqlEscape = (v: any): string => {
      if (v === null || v === undefined) return 'NULL';
      if (typeof v === 'boolean') return isMySQL ? (v ? '1' : '0') : (v ? 'TRUE' : 'FALSE');
      if (typeof v === 'number') return isNaN(v) ? 'NULL' : v.toString();
      if (typeof v === 'object') return `'${JSON.stringify(v).replace(/'/g, "''")}'`;
      return `'${String(v).replace(/'/g, "''")}'`;
    };

    const lines: string[] = [];
    lines.push(`-- ============================================================`);
    lines.push(`-- Nanupur Abu Sobhan High School Alumni Portal Database Dump`);
    lines.push(`-- 85th Anniversary Celebration & Grand Reunion 2027`);
    lines.push(`-- Dump Generated: ${timestamp}`);
    lines.push(`-- Target Engine: ${isMySQL ? 'MySQL 5.7+ / 8.0+ / MariaDB (cPanel phpMyAdmin)' : 'PostgreSQL 14+ / Supabase / Cloud SQL'}`);
    lines.push(`-- ============================================================\n`);

    if (isMySQL) {
      lines.push(`SET FOREIGN_KEY_CHECKS=0;`);
      lines.push(`SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";`);
      lines.push(`SET time_zone = "+00:00";`);
      lines.push(`/*!40101 SET NAMES utf8mb4 */;\n`);
    }

    // 1. TABLE: site_settings
    lines.push(`-- ------------------------------------------------------------`);
    lines.push(`-- 1. TABLE: site_settings`);
    lines.push(`-- ------------------------------------------------------------`);
    if (isMySQL) {
      lines.push(`CREATE TABLE IF NOT EXISTS \`site_settings\` (`);
      lines.push(`  \`id\` VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  \`key\` VARCHAR(100) UNIQUE NOT NULL,`);
      lines.push(`  \`value\` LONGTEXT NOT NULL,`);
      lines.push(`  \`description\` TEXT,`);
      lines.push(`  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP`);
      lines.push(`) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n`);
    } else {
      lines.push(`CREATE TABLE IF NOT EXISTS site_settings (`);
      lines.push(`  id VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  key VARCHAR(100) UNIQUE NOT NULL,`);
      lines.push(`  value JSONB NOT NULL,`);
      lines.push(`  description TEXT,`);
      lines.push(`  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
      lines.push(`);\n`);
    }

    const globalSettings = this.data.global_settings;
    if (globalSettings) {
      if (isMySQL) {
        lines.push(
          `INSERT INTO \`site_settings\` (\`id\`, \`key\`, \`value\`, \`description\`, \`updated_at\`) VALUES ('set-global', 'global_settings', ${sqlEscape(globalSettings)}, 'Global application settings', CURRENT_TIMESTAMP) ON DUPLICATE KEY UPDATE \`value\` = VALUES(\`value\`);`
        );
      } else {
        lines.push(
          `INSERT INTO site_settings (id, key, value, description, updated_at) VALUES ('set-global', 'global_settings', ${sqlEscape(globalSettings)}, 'Global application settings', CURRENT_TIMESTAMP) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;`
        );
      }
    }
    const regConfig = this.data.registration_config;
    if (regConfig) {
      if (isMySQL) {
        lines.push(
          `INSERT INTO \`site_settings\` (\`id\`, \`key\`, \`value\`, \`description\`, \`updated_at\`) VALUES ('set-reg', 'registration_config', ${sqlEscape(regConfig)}, 'Registration rules and fee tiers', CURRENT_TIMESTAMP) ON DUPLICATE KEY UPDATE \`value\` = VALUES(\`value\`);`
        );
      } else {
        lines.push(
          `INSERT INTO site_settings (id, key, value, description, updated_at) VALUES ('set-reg', 'registration_config', ${sqlEscape(regConfig)}, 'Registration rules and fee tiers', CURRENT_TIMESTAMP) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;`
        );
      }
    }
    lines.push('\n');

    // 2. TABLE: users
    lines.push(`-- ------------------------------------------------------------`);
    lines.push(`-- 2. TABLE: users`);
    lines.push(`-- ------------------------------------------------------------`);
    if (isMySQL) {
      lines.push(`CREATE TABLE IF NOT EXISTS \`users\` (`);
      lines.push(`  \`id\` VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  \`username\` VARCHAR(100) UNIQUE,`);
      lines.push(`  \`name\` VARCHAR(255) NOT NULL,`);
      lines.push(`  \`name_bn\` VARCHAR(255),`);
      lines.push(`  \`email\` VARCHAR(255) UNIQUE,`);
      lines.push(`  \`phone\` VARCHAR(50) UNIQUE,`);
      lines.push(`  \`password_hash\` VARCHAR(255),`);
      lines.push(`  \`role\` VARCHAR(50) DEFAULT 'alumni_member',`);
      lines.push(`  \`status\` VARCHAR(50) DEFAULT 'active',`);
      lines.push(`  \`passing_year\` INT,`);
      lines.push(`  \`batch\` VARCHAR(100),`);
      lines.push(`  \`dob\` VARCHAR(50),`);
      lines.push(`  \`gender\` VARCHAR(20),`);
      lines.push(`  \`blood_group\` VARCHAR(10),`);
      lines.push(`  \`photo_url\` TEXT,`);
      lines.push(`  \`occupation\` VARCHAR(255),`);
      lines.push(`  \`organization\` VARCHAR(255),`);
      lines.push(`  \`designation\` VARCHAR(255),`);
      lines.push(`  \`work_location\` VARCHAR(255),`);
      lines.push(`  \`address\` TEXT,`);
      lines.push(`  \`bio\` TEXT,`);
      lines.push(`  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
      lines.push(`) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n`);
    } else {
      lines.push(`CREATE TABLE IF NOT EXISTS users (`);
      lines.push(`  id VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  username VARCHAR(100) UNIQUE,`);
      lines.push(`  name VARCHAR(255) NOT NULL,`);
      lines.push(`  name_bn VARCHAR(255),`);
      lines.push(`  email VARCHAR(255) UNIQUE,`);
      lines.push(`  phone VARCHAR(50) UNIQUE,`);
      lines.push(`  password_hash VARCHAR(255),`);
      lines.push(`  role VARCHAR(50) DEFAULT 'alumni_member',`);
      lines.push(`  status VARCHAR(50) DEFAULT 'active',`);
      lines.push(`  passing_year INT,`);
      lines.push(`  batch VARCHAR(100),`);
      lines.push(`  dob VARCHAR(50),`);
      lines.push(`  gender VARCHAR(20),`);
      lines.push(`  blood_group VARCHAR(10),`);
      lines.push(`  photo_url TEXT,`);
      lines.push(`  occupation VARCHAR(255),`);
      lines.push(`  organization VARCHAR(255),`);
      lines.push(`  designation VARCHAR(255),`);
      lines.push(`  work_location VARCHAR(255),`);
      lines.push(`  address TEXT,`);
      lines.push(`  bio TEXT,`);
      lines.push(`  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
      lines.push(`);\n`);
    }

    const users = (this.get('users') || []);
    for (const u of users) {
      if (isMySQL) {
        lines.push(
          `INSERT INTO \`users\` (\`id\`, \`username\`, \`name\`, \`name_bn\`, \`email\`, \`phone\`, \`password_hash\`, \`role\`, \`status\`, \`passing_year\`, \`batch\`, \`dob\`, \`gender\`, \`blood_group\`, \`photo_url\`, \`occupation\`, \`organization\`, \`designation\`, \`work_location\`, \`address\`, \`bio\`, \`created_at\`) VALUES (${sqlEscape(u.id)}, ${sqlEscape(u.username)}, ${sqlEscape(u.name)}, ${sqlEscape(u.name_bn)}, ${sqlEscape(u.email)}, ${sqlEscape(u.phone)}, ${sqlEscape(u.password_hash)}, ${sqlEscape(u.role || 'alumni_member')}, ${sqlEscape(u.status || 'active')}, ${sqlEscape(u.passing_year)}, ${sqlEscape(u.batch)}, ${sqlEscape(u.dob)}, ${sqlEscape(u.gender)}, ${sqlEscape(u.blood_group)}, ${sqlEscape(u.photo_url)}, ${sqlEscape(u.occupation)}, ${sqlEscape(u.organization)}, ${sqlEscape(u.designation)}, ${sqlEscape(u.work_location)}, ${sqlEscape(u.address)}, ${sqlEscape(u.bio)}, ${sqlEscape(u.created_at || timestamp)}) ON DUPLICATE KEY UPDATE \`name\` = VALUES(\`name\`);`
        );
      } else {
        lines.push(
          `INSERT INTO users (id, username, name, name_bn, email, phone, password_hash, role, status, passing_year, batch, dob, gender, blood_group, photo_url, occupation, organization, designation, work_location, address, bio, created_at) VALUES (${sqlEscape(u.id)}, ${sqlEscape(u.username)}, ${sqlEscape(u.name)}, ${sqlEscape(u.name_bn)}, ${sqlEscape(u.email)}, ${sqlEscape(u.phone)}, ${sqlEscape(u.password_hash)}, ${sqlEscape(u.role || 'alumni_member')}, ${sqlEscape(u.status || 'active')}, ${sqlEscape(u.passing_year)}, ${sqlEscape(u.batch)}, ${sqlEscape(u.dob)}, ${sqlEscape(u.gender)}, ${sqlEscape(u.blood_group)}, ${sqlEscape(u.photo_url)}, ${sqlEscape(u.occupation)}, ${sqlEscape(u.organization)}, ${sqlEscape(u.designation)}, ${sqlEscape(u.work_location)}, ${sqlEscape(u.address)}, ${sqlEscape(u.bio)}, ${sqlEscape(u.created_at || timestamp)}) ON CONFLICT (id) DO NOTHING;`
        );
      }
    }
    lines.push('\n');

    // 3. TABLE: batches
    lines.push(`-- ------------------------------------------------------------`);
    lines.push(`-- 3. TABLE: batches`);
    lines.push(`-- ------------------------------------------------------------`);
    if (isMySQL) {
      lines.push(`CREATE TABLE IF NOT EXISTS \`batches\` (`);
      lines.push(`  \`id\` VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  \`name_en\` VARCHAR(255) NOT NULL,`);
      lines.push(`  \`name_bn\` VARCHAR(255) NOT NULL,`);
      lines.push(`  \`passing_year\` INT UNIQUE NOT NULL,`);
      lines.push(`  \`batch_number\` INT,`);
      lines.push(`  \`representative_name\` VARCHAR(255),`);
      lines.push(`  \`representative_phone\` VARCHAR(50),`);
      lines.push(`  \`is_active\` BOOLEAN DEFAULT TRUE,`);
      lines.push(`  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
      lines.push(`) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n`);
    } else {
      lines.push(`CREATE TABLE IF NOT EXISTS batches (`);
      lines.push(`  id VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  name_en VARCHAR(255) NOT NULL,`);
      lines.push(`  name_bn VARCHAR(255) NOT NULL,`);
      lines.push(`  passing_year INT UNIQUE NOT NULL,`);
      lines.push(`  batch_number INT,`);
      lines.push(`  representative_name VARCHAR(255),`);
      lines.push(`  representative_phone VARCHAR(50),`);
      lines.push(`  is_active BOOLEAN DEFAULT TRUE,`);
      lines.push(`  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
      lines.push(`);\n`);
    }

    const batches = this.data.batches || [];
    for (const b of batches) {
      if (isMySQL) {
        lines.push(
          `INSERT INTO \`batches\` (\`id\`, \`name_en\`, \`name_bn\`, \`passing_year\`, \`batch_number\`, \`representative_name\`, \`representative_phone\`, \`is_active\`) VALUES (${sqlEscape(b.id)}, ${sqlEscape(b.name_en)}, ${sqlEscape(b.name_bn)}, ${sqlEscape(b.passing_year)}, ${sqlEscape(b.batch_number)}, ${sqlEscape(b.representative_name)}, ${sqlEscape(b.representative_phone)}, ${sqlEscape(b.is_active !== false)}) ON DUPLICATE KEY UPDATE \`name_en\` = VALUES(\`name_en\`);`
        );
      } else {
        lines.push(
          `INSERT INTO batches (id, name_en, name_bn, passing_year, batch_number, representative_name, representative_phone, is_active) VALUES (${sqlEscape(b.id)}, ${sqlEscape(b.name_en)}, ${sqlEscape(b.name_bn)}, ${sqlEscape(b.passing_year)}, ${sqlEscape(b.batch_number)}, ${sqlEscape(b.representative_name)}, ${sqlEscape(b.representative_phone)}, ${sqlEscape(b.is_active !== false)}) ON CONFLICT (id) DO NOTHING;`
        );
      }
    }
    lines.push('\n');

    // 4. TABLE: events
    lines.push(`-- ------------------------------------------------------------`);
    lines.push(`-- 4. TABLE: events`);
    lines.push(`-- ------------------------------------------------------------`);
    if (isMySQL) {
      lines.push(`CREATE TABLE IF NOT EXISTS \`events\` (`);
      lines.push(`  \`id\` VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  \`slug\` VARCHAR(255) UNIQUE NOT NULL,`);
      lines.push(`  \`title_en\` VARCHAR(255) NOT NULL,`);
      lines.push(`  \`title_bn\` VARCHAR(255) NOT NULL,`);
      lines.push(`  \`tagline_en\` TEXT,`);
      lines.push(`  \`tagline_bn\` TEXT,`);
      lines.push(`  \`description_en\` TEXT,`);
      lines.push(`  \`description_bn\` TEXT,`);
      lines.push(`  \`event_date\` DATE NOT NULL,`);
      lines.push(`  \`venue_en\` VARCHAR(255),`);
      lines.push(`  \`venue_bn\` VARCHAR(255),`);
      lines.push(`  \`registration_deadline\` DATE,`);
      lines.push(`  \`registration_fee\` NUMERIC(10, 2) DEFAULT 1000.00,`);
      lines.push(`  \`max_capacity\` INT DEFAULT 5000,`);
      lines.push(`  \`status\` VARCHAR(50) DEFAULT 'published'`);
      lines.push(`) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n`);
    } else {
      lines.push(`CREATE TABLE IF NOT EXISTS events (`);
      lines.push(`  id VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  slug VARCHAR(255) UNIQUE NOT NULL,`);
      lines.push(`  title_en VARCHAR(255) NOT NULL,`);
      lines.push(`  title_bn VARCHAR(255) NOT NULL,`);
      lines.push(`  tagline_en TEXT,`);
      lines.push(`  tagline_bn TEXT,`);
      lines.push(`  description_en TEXT,`);
      lines.push(`  description_bn TEXT,`);
      lines.push(`  event_date DATE NOT NULL,`);
      lines.push(`  venue_en VARCHAR(255),`);
      lines.push(`  venue_bn VARCHAR(255),`);
      lines.push(`  registration_deadline DATE,`);
      lines.push(`  registration_fee NUMERIC(10, 2) DEFAULT 1000.00,`);
      lines.push(`  max_capacity INT DEFAULT 5000,`);
      lines.push(`  status VARCHAR(50) DEFAULT 'published'`);
      lines.push(`);\n`);
    }

    const events = this.data.events || [];
    for (const e of events) {
      if (isMySQL) {
        lines.push(
          `INSERT INTO \`events\` (\`id\`, \`slug\`, \`title_en\`, \`title_bn\`, \`tagline_en\`, \`tagline_bn\`, \`description_en\`, \`description_bn\`, \`event_date\`, \`venue_en\`, \`venue_bn\`, \`registration_deadline\`, \`registration_fee\`, \`max_capacity\`, \`status\`) VALUES (${sqlEscape(e.id)}, ${sqlEscape(e.slug || '85th-anniversary')}, ${sqlEscape(e.title_en)}, ${sqlEscape(e.title_bn)}, ${sqlEscape(e.tagline_en)}, ${sqlEscape(e.tagline_bn)}, ${sqlEscape(e.description_en)}, ${sqlEscape(e.description_bn)}, ${sqlEscape(e.event_date || '2027-01-16')}, ${sqlEscape(e.venue_en)}, ${sqlEscape(e.venue_bn)}, ${sqlEscape((e as any).registration_deadline || e.registration_end || '2026-12-31')}, ${sqlEscape(e.registration_fee || 1000)}, ${sqlEscape(e.max_capacity || 5000)}, ${sqlEscape(e.status || 'published')}) ON DUPLICATE KEY UPDATE \`title_en\` = VALUES(\`title_en\`);`
        );
      } else {
        lines.push(
          `INSERT INTO events (id, slug, title_en, title_bn, tagline_en, tagline_bn, description_en, description_bn, event_date, venue_en, venue_bn, registration_deadline, registration_fee, max_capacity, status) VALUES (${sqlEscape(e.id)}, ${sqlEscape(e.slug || '85th-anniversary')}, ${sqlEscape(e.title_en)}, ${sqlEscape(e.title_bn)}, ${sqlEscape(e.tagline_en)}, ${sqlEscape(e.tagline_bn)}, ${sqlEscape(e.description_en)}, ${sqlEscape(e.description_bn)}, ${sqlEscape(e.event_date || '2027-01-16')}, ${sqlEscape(e.venue_en)}, ${sqlEscape(e.venue_bn)}, ${sqlEscape((e as any).registration_deadline || e.registration_end || '2026-12-31')}, ${sqlEscape(e.registration_fee || 1000)}, ${sqlEscape(e.max_capacity || 5000)}, ${sqlEscape(e.status || 'published')}) ON CONFLICT (id) DO NOTHING;`
        );
      }
    }
    lines.push('\n');

    // 5. TABLE: event_registrations
    lines.push(`-- ------------------------------------------------------------`);
    lines.push(`-- 5. TABLE: event_registrations`);
    lines.push(`-- ------------------------------------------------------------`);
    if (isMySQL) {
      lines.push(`CREATE TABLE IF NOT EXISTS \`event_registrations\` (`);
      lines.push(`  \`id\` VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  \`event_id\` VARCHAR(100),`);
      lines.push(`  \`full_name\` VARCHAR(255) NOT NULL,`);
      lines.push(`  \`dob\` VARCHAR(50),`);
      lines.push(`  \`gender\` VARCHAR(20),`);
      lines.push(`  \`blood_group\` VARCHAR(10),`);
      lines.push(`  \`t_shirt_size\` VARCHAR(10),`);
      lines.push(`  \`phone\` VARCHAR(50) NOT NULL,`);
      lines.push(`  \`email\` VARCHAR(255),`);
      lines.push(`  \`passing_year\` INT NOT NULL,`);
      lines.push(`  \`batch_id\` VARCHAR(100),`);
      lines.push(`  \`batch_name\` VARCHAR(100),`);
      lines.push(`  \`batch_name_bn\` VARCHAR(100),`);
      lines.push(`  \`fee_amount\` NUMERIC(10, 2) DEFAULT 1000.00,`);
      lines.push(`  \`currency\` VARCHAR(10) DEFAULT 'BDT',`);
      lines.push(`  \`payment_status\` VARCHAR(50) DEFAULT 'pending',`);
      lines.push(`  \`registration_status\` VARCHAR(50) DEFAULT 'pending',`);
      lines.push(`  \`payment_method\` VARCHAR(50),`);
      lines.push(`  \`token_id\` VARCHAR(100),`);
      lines.push(`  \`token_code\` VARCHAR(100),`);
      lines.push(`  \`checked_in\` BOOLEAN DEFAULT FALSE,`);
      lines.push(`  \`checked_in_at\` TIMESTAMP NULL,`);
      lines.push(`  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
      lines.push(`) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n`);
    } else {
      lines.push(`CREATE TABLE IF NOT EXISTS event_registrations (`);
      lines.push(`  id VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  event_id VARCHAR(100),`);
      lines.push(`  full_name VARCHAR(255) NOT NULL,`);
      lines.push(`  dob VARCHAR(50),`);
      lines.push(`  gender VARCHAR(20),`);
      lines.push(`  blood_group VARCHAR(10),`);
      lines.push(`  t_shirt_size VARCHAR(10),`);
      lines.push(`  phone VARCHAR(50) NOT NULL,`);
      lines.push(`  email VARCHAR(255),`);
      lines.push(`  passing_year INT NOT NULL,`);
      lines.push(`  batch_id VARCHAR(100),`);
      lines.push(`  batch_name VARCHAR(100),`);
      lines.push(`  batch_name_bn VARCHAR(100),`);
      lines.push(`  fee_amount NUMERIC(10, 2) DEFAULT 1000.00,`);
      lines.push(`  currency VARCHAR(10) DEFAULT 'BDT',`);
      lines.push(`  payment_status VARCHAR(50) DEFAULT 'pending',`);
      lines.push(`  registration_status VARCHAR(50) DEFAULT 'pending',`);
      lines.push(`  payment_method VARCHAR(50),`);
      lines.push(`  token_id VARCHAR(100),`);
      lines.push(`  token_code VARCHAR(100),`);
      lines.push(`  checked_in BOOLEAN DEFAULT FALSE,`);
      lines.push(`  checked_in_at TIMESTAMP,`);
      lines.push(`  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
      lines.push(`);\n`);
    }

    const registrations = this.data.registrations || [];
    for (const r of registrations) {
      if (isMySQL) {
        lines.push(
          `INSERT INTO \`event_registrations\` (\`id\`, \`event_id\`, \`full_name\`, \`dob\`, \`gender\`, \`blood_group\`, \`t_shirt_size\`, \`phone\`, \`email\`, \`passing_year\`, \`batch_id\`, \`batch_name\`, \`batch_name_bn\`, \`fee_amount\`, \`currency\`, \`payment_status\`, \`registration_status\`, \`payment_method\`, \`token_id\`, \`token_code\`, \`checked_in\`, \`checked_in_at\`, \`created_at\`) VALUES (${sqlEscape(r.id)}, ${sqlEscape(r.event_id || 'event-85th-anniversary')}, ${sqlEscape(r.full_name)}, ${sqlEscape(r.dob)}, ${sqlEscape(r.gender)}, ${sqlEscape(r.blood_group)}, ${sqlEscape(r.t_shirt_size || null)}, ${sqlEscape(r.phone)}, ${sqlEscape(r.email)}, ${sqlEscape(r.passing_year)}, ${sqlEscape(r.batch_id)}, ${sqlEscape(r.batch_name)}, ${sqlEscape(r.batch_name_bn)}, ${sqlEscape(r.fee_amount || 1000)}, ${sqlEscape(r.currency || 'BDT')}, ${sqlEscape(r.payment_status || 'pending')}, ${sqlEscape(r.registration_status || 'pending')}, ${sqlEscape(r.payment_method)}, ${sqlEscape(r.token_id)}, ${sqlEscape(r.token_code)}, ${sqlEscape(r.checked_in || false)}, ${sqlEscape(r.checked_in_at)}, ${sqlEscape(r.created_at || timestamp)}) ON DUPLICATE KEY UPDATE \`payment_status\` = VALUES(\`payment_status\`);`
        );
      } else {
        lines.push(
          `INSERT INTO event_registrations (id, event_id, full_name, dob, gender, blood_group, t_shirt_size, phone, email, passing_year, batch_id, batch_name, batch_name_bn, fee_amount, currency, payment_status, registration_status, payment_method, token_id, token_code, checked_in, checked_in_at, created_at) VALUES (${sqlEscape(r.id)}, ${sqlEscape(r.event_id || 'event-85th-anniversary')}, ${sqlEscape(r.full_name)}, ${sqlEscape(r.dob)}, ${sqlEscape(r.gender)}, ${sqlEscape(r.blood_group)}, ${sqlEscape(r.t_shirt_size || null)}, ${sqlEscape(r.phone)}, ${sqlEscape(r.email)}, ${sqlEscape(r.passing_year)}, ${sqlEscape(r.batch_id)}, ${sqlEscape(r.batch_name)}, ${sqlEscape(r.batch_name_bn)}, ${sqlEscape(r.fee_amount || 1000)}, ${sqlEscape(r.currency || 'BDT')}, ${sqlEscape(r.payment_status || 'pending')}, ${sqlEscape(r.registration_status || 'pending')}, ${sqlEscape(r.payment_method)}, ${sqlEscape(r.token_id)}, ${sqlEscape(r.token_code)}, ${sqlEscape(r.checked_in || false)}, ${sqlEscape(r.checked_in_at)}, ${sqlEscape(r.created_at || timestamp)}) ON CONFLICT (id) DO NOTHING;`
        );
      }
    }
    lines.push('\n');

    // 6. TABLE: entry_tokens
    lines.push(`-- ------------------------------------------------------------`);
    lines.push(`-- 6. TABLE: entry_tokens`);
    lines.push(`-- ------------------------------------------------------------`);
    if (isMySQL) {
      lines.push(`CREATE TABLE IF NOT EXISTS \`entry_tokens\` (`);
      lines.push(`  \`id\` VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  \`token_code\` VARCHAR(100) UNIQUE NOT NULL,`);
      lines.push(`  \`registration_id\` VARCHAR(100),`);
      lines.push(`  \`event_id\` VARCHAR(100),`);
      lines.push(`  \`member_name\` VARCHAR(255) NOT NULL,`);
      lines.push(`  \`batch_name\` VARCHAR(100),`);
      lines.push(`  \`batch_name_bn\` VARCHAR(100),`);
      lines.push(`  \`status\` VARCHAR(50) DEFAULT 'active',`);
      lines.push(`  \`checked_in\` BOOLEAN DEFAULT FALSE,`);
      lines.push(`  \`checked_in_at\` TIMESTAMP NULL,`);
      lines.push(`  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
      lines.push(`) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n`);
    } else {
      lines.push(`CREATE TABLE IF NOT EXISTS entry_tokens (`);
      lines.push(`  id VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  token_code VARCHAR(100) UNIQUE NOT NULL,`);
      lines.push(`  registration_id VARCHAR(100),`);
      lines.push(`  event_id VARCHAR(100),`);
      lines.push(`  member_name VARCHAR(255) NOT NULL,`);
      lines.push(`  batch_name VARCHAR(100),`);
      lines.push(`  batch_name_bn VARCHAR(100),`);
      lines.push(`  status VARCHAR(50) DEFAULT 'active',`);
      lines.push(`  checked_in BOOLEAN DEFAULT FALSE,`);
      lines.push(`  checked_in_at TIMESTAMP,`);
      lines.push(`  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
      lines.push(`);\n`);
    }

    const tokens = this.data.tokens || [];
    for (const t of tokens) {
      if (isMySQL) {
        lines.push(
          `INSERT INTO \`entry_tokens\` (\`id\`, \`token_code\`, \`registration_id\`, \`event_id\`, \`member_name\`, \`batch_name\`, \`batch_name_bn\`, \`status\`, \`checked_in\`, \`checked_in_at\`, \`created_at\`) VALUES (${sqlEscape(t.id)}, ${sqlEscape(t.token_code)}, ${sqlEscape(t.registration_id)}, ${sqlEscape(t.event_id || 'event-85th-anniversary')}, ${sqlEscape(t.member_name)}, ${sqlEscape(t.batch_name)}, ${sqlEscape(t.batch_name_bn)}, ${sqlEscape(t.status || 'active')}, ${sqlEscape(t.checked_in || false)}, ${sqlEscape(t.checked_in_at)}, ${sqlEscape(t.created_at || timestamp)}) ON DUPLICATE KEY UPDATE \`status\` = VALUES(\`status\`);`
        );
      } else {
        lines.push(
          `INSERT INTO entry_tokens (id, token_code, registration_id, event_id, member_name, batch_name, batch_name_bn, status, checked_in, checked_in_at, created_at) VALUES (${sqlEscape(t.id)}, ${sqlEscape(t.token_code)}, ${sqlEscape(t.registration_id)}, ${sqlEscape(t.event_id || 'event-85th-anniversary')}, ${sqlEscape(t.member_name)}, ${sqlEscape(t.batch_name)}, ${sqlEscape(t.batch_name_bn)}, ${sqlEscape(t.status || 'active')}, ${sqlEscape(t.checked_in || false)}, ${sqlEscape(t.checked_in_at)}, ${sqlEscape(t.created_at || timestamp)}) ON CONFLICT (id) DO NOTHING;`
        );
      }
    }
    lines.push('\n');

    // 7. TABLE: offline_centers (Authorized Registration Booths)
    lines.push(`-- ------------------------------------------------------------`);
    lines.push(`-- 7. TABLE: offline_centers (Authorized Registration Booths)`);
    lines.push(`-- ------------------------------------------------------------`);
    if (isMySQL) {
      lines.push(`CREATE TABLE IF NOT EXISTS \`offline_centers\` (`);
      lines.push(`  \`id\` VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  \`name_en\` VARCHAR(255) NOT NULL,`);
      lines.push(`  \`name_bn\` VARCHAR(255) NOT NULL,`);
      lines.push(`  \`address_en\` TEXT,`);
      lines.push(`  \`address_bn\` TEXT,`);
      lines.push(`  \`phone\` VARCHAR(50) NOT NULL,`);
      lines.push(`  \`contact_person\` VARCHAR(255),`);
      lines.push(`  \`timings\` VARCHAR(255),`);
      lines.push(`  \`map_url\` TEXT,`);
      lines.push(`  \`order_index\` INT DEFAULT 1,`);
      lines.push(`  \`is_active\` BOOLEAN DEFAULT TRUE,`);
      lines.push(`  \`is_trashed\` BOOLEAN DEFAULT FALSE,`);
      lines.push(`  \`deleted_at\` TIMESTAMP NULL,`);
      lines.push(`  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
      lines.push(`) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n`);
    } else {
      lines.push(`CREATE TABLE IF NOT EXISTS offline_centers (`);
      lines.push(`  id VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  name_en VARCHAR(255) NOT NULL,`);
      lines.push(`  name_bn VARCHAR(255) NOT NULL,`);
      lines.push(`  address_en TEXT,`);
      lines.push(`  address_bn TEXT,`);
      lines.push(`  phone VARCHAR(50) NOT NULL,`);
      lines.push(`  contact_person VARCHAR(255),`);
      lines.push(`  timings VARCHAR(255),`);
      lines.push(`  map_url TEXT,`);
      lines.push(`  order_index INT DEFAULT 1,`);
      lines.push(`  is_active BOOLEAN DEFAULT TRUE,`);
      lines.push(`  is_trashed BOOLEAN DEFAULT FALSE,`);
      lines.push(`  deleted_at TIMESTAMP NULL,`);
      lines.push(`  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);
      lines.push(`);\n`);
    }

    const booths = this.data.offline_centers || [];
    for (const b of booths) {
      if (isMySQL) {
        lines.push(
          `INSERT INTO \`offline_centers\` (\`id\`, \`name_en\`, \`name_bn\`, \`address_en\`, \`address_bn\`, \`phone\`, \`contact_person\`, \`timings\`, \`map_url\`, \`order_index\`, \`is_active\`, \`is_trashed\`) VALUES (${sqlEscape(b.id)}, ${sqlEscape(b.name_en)}, ${sqlEscape(b.name_bn)}, ${sqlEscape(b.address_en)}, ${sqlEscape(b.address_bn)}, ${sqlEscape(b.phone)}, ${sqlEscape(b.contact_person)}, ${sqlEscape(b.timings)}, ${sqlEscape(b.map_url)}, ${b.order_index || 1}, ${b.is_active !== false}, ${b.is_trashed === true}) ON DUPLICATE KEY UPDATE \`name_en\` = VALUES(\`name_en\`);`
        );
      } else {
        lines.push(
          `INSERT INTO offline_centers (id, name_en, name_bn, address_en, address_bn, phone, contact_person, timings, map_url, order_index, is_active, is_trashed) VALUES (${sqlEscape(b.id)}, ${sqlEscape(b.name_en)}, ${sqlEscape(b.name_bn)}, ${sqlEscape(b.address_en)}, ${sqlEscape(b.address_bn)}, ${sqlEscape(b.phone)}, ${sqlEscape(b.contact_person)}, ${sqlEscape(b.timings)}, ${sqlEscape(b.map_url)}, ${b.order_index || 1}, ${b.is_active !== false}, ${b.is_trashed === true}) ON CONFLICT (id) DO NOTHING;`
        );
      }
    }
    lines.push('\n');

    // 8. TABLE: media_items (Registration Photos & Admin Uploads)
    lines.push(`-- ------------------------------------------------------------`);
    lines.push(`-- 8. TABLE: media_items (Registration Photos & Admin Assets)`);
    lines.push(`-- ------------------------------------------------------------`);
    if (isMySQL) {
      lines.push(`CREATE TABLE IF NOT EXISTS \`media_items\` (`);
      lines.push(`  \`id\` VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  \`name\` VARCHAR(255) NOT NULL,`);
      lines.push(`  \`filename\` VARCHAR(255),`);
      lines.push(`  \`url\` VARCHAR(500) NOT NULL,`);
      lines.push(`  \`type\` VARCHAR(100) DEFAULT 'image/jpeg',`);
      lines.push(`  \`size\` VARCHAR(50) DEFAULT '1.0 MB',`);
      lines.push(`  \`size_bytes\` BIGINT DEFAULT 0,`);
      lines.push(`  \`registration_id\` VARCHAR(100),`);
      lines.push(`  \`user_id\` VARCHAR(100),`);
      lines.push(`  \`source\` VARCHAR(50) DEFAULT 'upload',`);
      lines.push(`  \`attendee_name\` VARCHAR(191),`);
      lines.push(`  \`passing_year\` INT,`);
      lines.push(`  \`token_code\` VARCHAR(100),`);
      lines.push(`  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,`);
      lines.push(`  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,`);
      lines.push(`  INDEX \`idx_media_reg_id\` (\`registration_id\`),`);
      lines.push(`  INDEX \`idx_media_source\` (\`source\`)`);
      lines.push(`) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n`);
    } else {
      lines.push(`CREATE TABLE IF NOT EXISTS media_items (`);
      lines.push(`  id VARCHAR(100) PRIMARY KEY,`);
      lines.push(`  name VARCHAR(255) NOT NULL,`);
      lines.push(`  filename VARCHAR(255),`);
      lines.push(`  url VARCHAR(500) NOT NULL,`);
      lines.push(`  type VARCHAR(100) DEFAULT 'image/jpeg',`);
      lines.push(`  size VARCHAR(50) DEFAULT '1.0 MB',`);
      lines.push(`  size_bytes BIGINT DEFAULT 0,`);
      lines.push(`  registration_id VARCHAR(100),`);
      lines.push(`  user_id VARCHAR(100),`);
      lines.push(`  source VARCHAR(50) DEFAULT 'upload',`);
      lines.push(`  attendee_name VARCHAR(191),`);
      lines.push(`  passing_year INT,`);
      lines.push(`  token_code VARCHAR(100),`);
      lines.push(`  created_at TIMESTAMPTZ DEFAULT NOW(),`);
      lines.push(`  updated_at TIMESTAMPTZ DEFAULT NOW()`);
      lines.push(`);\n`);
    }

    const mediaItems = this.data.media || [];
    for (const m of mediaItems) {
      if (isMySQL) {
        lines.push(
          `INSERT INTO \`media_items\` (\`id\`, \`name\`, \`filename\`, \`url\`, \`type\`, \`size\`, \`size_bytes\`, \`registration_id\`, \`user_id\`, \`source\`, \`attendee_name\`, \`passing_year\`, \`token_code\`, \`created_at\`) VALUES (${sqlEscape(m.id)}, ${sqlEscape(m.name)}, ${sqlEscape(m.filename)}, ${sqlEscape(m.url)}, ${sqlEscape(m.type)}, ${sqlEscape(m.size)}, ${m.size_bytes || 0}, ${sqlEscape(m.registration_id)}, ${sqlEscape(m.user_id)}, ${sqlEscape(m.source || 'upload')}, ${sqlEscape(m.attendee_name)}, ${m.passing_year ? parseInt(String(m.passing_year), 10) : 'NULL'}, ${sqlEscape(m.token_code)}, ${sqlEscape(m.created_at || timestamp)}) ON DUPLICATE KEY UPDATE \`name\` = VALUES(\`name\`), \`url\` = VALUES(\`url\`);`
        );
      } else {
        lines.push(
          `INSERT INTO media_items (id, name, filename, url, type, size, size_bytes, registration_id, user_id, source, attendee_name, passing_year, token_code, created_at) VALUES (${sqlEscape(m.id)}, ${sqlEscape(m.name)}, ${sqlEscape(m.filename)}, ${sqlEscape(m.url)}, ${sqlEscape(m.type)}, ${sqlEscape(m.size)}, ${m.size_bytes || 0}, ${sqlEscape(m.registration_id)}, ${sqlEscape(m.user_id)}, ${sqlEscape(m.source || 'upload')}, ${sqlEscape(m.attendee_name)}, ${m.passing_year ? parseInt(String(m.passing_year), 10) : 'NULL'}, ${sqlEscape(m.token_code)}, ${sqlEscape(m.created_at || timestamp)}) ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, url = EXCLUDED.url;`
        );
      }
    }
    lines.push('\n');

    if (isMySQL) {
      lines.push(`SET FOREIGN_KEY_CHECKS=1;`);
    }
    lines.push(`-- End of Backup Dump (${isMySQL ? 'cPanel MySQL' : 'Cloud SQL / PostgreSQL'})`);
    return lines.join('\n');
  }
}

export const db = new DatabaseEngine();
export { portableDb } from './db/portableDb';

